/* $Id: vdivalppl.m,v 1.5 2001/11/09 15:04:29 ahundiak Exp $  */

/***************************************************************************
 * I/VDS
 *
 * File:        vdat/pcmk2/vdiatppl.m
 *
 * Description: 
 *
 * Dependencies:
 *
 * Revision History:
 *      $Log: vdivalppl.m,v $
 *      Revision 1.5  2001/11/09 15:04:29  ahundiak
 *      ah
 *
 *      Revision 1.4  2001/08/24 20:01:52  ahundiak
 *      ah
 *
 *      Revision 1.3  2001/08/14 19:15:45  ahundiak
 *      ah
 *
 *      Revision 1.2  2001/08/02 15:33:39  ahundiak
 *      ah
 *
 *      Revision 1.1  2001/07/23 16:32:23  ahundiak
 *      ah
 *
 *
 * History:
 * MM/DD/YY  AUTHOR  DESCRIPTION
 * 07/10/01  ah      Created
 ***************************************************************************/

CCIOPT        -Xnoargchk -m -q
COxml_piece.u
COxml_stdpc.u
COxml_eqp.u
COxml_eqpo.u
COxml_eqpi.u
xml_piece.u
xml_stdpc.u
xml_eqp.u
xml_noz.u
xml_cpt.u
xml_comp.u
COvalSP.u
COxml_comp.u
COxml_compi.u
COxml_compo.u




