/* $Id: vdirrvppl.m,v 1.7 2002/02/28 21:41:34 ahundiak Exp $  */

/***************************************************************************
 * I/VDS
 *
 * File:        vdcty/rrv/vdirrvppl.m
 *
 * Description: 
 *
 * Dependencies:
 *
 * Revision History:
 *      $Log: vdirrvppl.m,v $
 *      Revision 1.7  2002/02/28 21:41:34  ahundiak
 *      ah
 *
 *      Revision 1.6  2001/09/04 13:30:33  ahundiak
 *      ah
 *
 *      Revision 1.5  2001/06/03 14:51:01  ahundiak
 *      *** empty log message ***
 *
 *      Revision 1.4  2001/03/09 15:15:19  ahundiak
 *      ah
 *
 *      Revision 1.3  2001/02/22 22:42:33  ahundiak
 *      *** empty log message ***
 *
 *      Revision 1.2  2001/02/20 15:21:32  ahundiak
 *      *** empty log message ***
 *
 *      Revision 1.1  2001/02/17 14:23:45  ahundiak
 *      *** empty log message ***
 *
 *
 * History:
 * MM/DD/YY  AUTHOR  DESCRIPTION
 * 02/15/01  ah      Created
 ***************************************************************************/

CCIOPT        -Xnoargchk -m -q
COssRev.u
COssCre.u
COssPurpose.u
COssList.u





