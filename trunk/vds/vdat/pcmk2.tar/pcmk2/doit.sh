grmake
ldso /export/home/impd/isdp/vds/lib/vdiatpcmk2
mv   /export/home/impd/isdp/vds/lib/vdiatpcmk2.so /usr/tmp/at.so
echo "### DONE IT ###"