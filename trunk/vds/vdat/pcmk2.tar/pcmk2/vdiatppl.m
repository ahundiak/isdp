/* $Id: vdiatppl.m,v 1.5 2002/04/18 16:33:32 ahundiak Exp $  */

/***************************************************************************
 * I/VDS
 *
 * File:        vdat/pcmk2/vdiatppl.m
 *
 * Description: 
 *
 * Dependencies:
 *
 * Revision History:
 *      $Log: vdiatppl.m,v $
 *      Revision 1.5  2002/04/18 16:33:32  ahundiak
 *      ah
 *
 *      Revision 1.4  2002/02/28 22:23:11  ahundiak
 *      ah
 *
 *      Revision 1.3  2002/01/03 14:27:01  ahundiak
 *      ah
 *
 *      Revision 1.2  2001/07/20 13:07:54  ahundiak
 *      ah
 *
 *      Revision 1.1  2001/03/16 17:10:46  ahundiak
 *      *** empty log message ***
 *
 *
 * History:
 * MM/DD/YY  AUTHOR  DESCRIPTION
 * 03/13/01  ah      Created
 * 07/20/01  ah      Put the update here for now, move to ppl for the pload
 ***************************************************************************/

CCIOPT        -Xnoargchk -m -q
crv_tran.u
srf_tran.u
COsrf_tran.u
COatMgrUpd.u
COatNextPc.u
COatStdGeom.u
COatDelGeom.u
COatStdLib.u
pcmk_list.u
pcmk_sync.u



