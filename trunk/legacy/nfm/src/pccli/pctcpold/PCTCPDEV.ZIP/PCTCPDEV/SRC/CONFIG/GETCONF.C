/*
 * $Header:   H:/22vcs/srclib/config/getconf.c_v   1.4   14 Sep 1992 16:07:54   paul  $
 */

/* getconf.c	emulation of the 2.05 getconf() function.
 */

/* Copyright (C) 1991, 1992 by FTP Software, Inc.  All rights reserved.
 * 
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 * 
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 * 
 * Edit History
 * 23-Jun-91	rehmi	emulate the old getconf() function in the new regime.
 * 28-Oct-91	Ben	If config_read in getconf fails try again with 
 *			 by converting '_' to '-', or vice versa.
 * 05-Nov-91	paul	added function return types
 * 26-Mar-92	Ben	Go back to simple getconf().
 * 30-Mar-92	Ben	Fixed a misplaced ')'.
 * 21-Jul-92	rcq	changed to <rwconf.h> to <pctcp/rwconf.h>
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <pctcp/rwconf.h>

#define TRUE (0==0)
#define FALSE (!TRUE)

int
getconf (char *section, char *name, char *value, int len)
{
	return	((_config_FILE || config_open(NULL, 0)) &&	
	    config_seek ("pctcp", section, CONF_ANY, 0) &&
	    config_read (name, 0, value, len, 0));
	    /* conditional in-order evaluation */
}

int
getconf_init(int how)
{
	switch (how) {
	case CI_REWIND:
		config_seek (CONF_ANY, CONF_ANY, CONF_ANY, CONF_REWIND);
		break;

	case CI_CLOSE:
		config_close (0);
		break;
		
	default:
		return FALSE;	/* we will only do so much. */
	}

	return TRUE;
}

/*
 * $Log:   H:/22vcs/srclib/config/getconf.c_v  $
 * 
 *    Rev 1.4   14 Sep 1992 16:07:54   paul
 *  * 21-Jul-92	rcq	changed to <rwconf.h> to <pctcp/rwconf.h>
 * 
 *    Rev 1.3   30 Mar 1992 16:15:16   arnoff
 * Fixed a misplaced ')'.   ---Ben
 * 
 *    Rev 1.2   27 Mar 1992 19:51:20   arnoff
 * Renamed _config_FILE to _curr_FILE.  Go back to simple getconf().   ---Ben
 *
 *    Rev 1.1   30 Jan 1992 00:06:12   arnoff
 *  
 */
