/* 
 * $Header:   J:/22vcs/srclib/rpc4/r_common.c_v   1.0   10 Nov 1992 22:59:26   rcq  $
 */
#define FTP /*Copyright 1992, FTP Software, Inc.  All Rights Reserved.*/
#ifdef FTP /* added code */
/*
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 * 
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 *
 * (Edit history is maintained in RCS archives.)
 */
#else /* FTP superceded code */
/* @(#)rpc_commondata.c	2.1 88/07/29 4.0 RPCSRC */
/*
 * Sun RPC is a product of Sun Microsystems, Inc. and is provided for
 * unrestricted use provided that this legend is included on all tape
 * media and as a part of the software program in whole or part.  Users
 * may copy or modify Sun RPC without charge, but are not authorized
 * to license or distribute it to anyone else except as part of a product or
 * program developed by the user.
 * 
 * SUN RPC IS PROVIDED AS IS WITH NO WARRANTIES OF ANY KIND INCLUDING THE
 * WARRANTIES OF DESIGN, MERCHANTIBILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, OR ARISING FROM A COURSE OF DEALING, USAGE OR TRADE PRACTICE.
 * 
 * Sun RPC is provided with no support and without any obligation on the
 * part of Sun Microsystems, Inc. to assist in its use, correction,
 * modification or enhancement.
 * 
 * SUN MICROSYSTEMS, INC. SHALL HAVE NO LIABILITY WITH RESPECT TO THE
 * INFRINGEMENT OF COPYRIGHTS, TRADE SECRETS OR ANY PATENTS BY SUN RPC
 * OR ANY PART THEREOF.
 * 
 * In no event will Sun Microsystems, Inc. be liable for any lost revenue
 * or profits or other special, indirect and consequential damages, even if
 * Sun has been advised of the possibility of such damages.
 * 
 * Sun Microsystems, Inc.
 * 2550 Garcia Avenue
 * Mountain View, California  94043
 */
#endif /* FTP */
#include <rpc/rpc.h>
/*
 * This file should only contain common data (global data) that is exported
 * by public interfaces 
 */
#ifdef FTP /* added code */

struct opaque_auth _null_auth = { 0 }; /* Make sure linker can find this */
#ifdef FD_SETSIZE
fd_set svc_fdset;
#else
unsigned long svc_fds = 0;
#endif /* def FD_SETSIZE */
struct rpc_createerr rpc_createerr = { 0 }; /* Make sure linker finds this */

#else /* FTP superceded code */
struct opaque_auth _null_auth;
#ifdef FD_SETSIZE
fd_set svc_fdset;
#else
int svc_fds;
#endif /* def FD_SETSIZE */
struct rpc_createerr rpc_createerr;
#endif /* FTP */
/* 
 * $Log:   J:/22vcs/srclib/rpc4/r_common.c_v  $
 * 
 *    Rev 1.0   10 Nov 1992 22:59:26   rcq
 * Initial revision.
 */