/*
 * $Header:   K:/21vcs/srclib/config/custstub.c_v   1.1   13 Jul 1992 21:05:38   arnoff  $
 */

/* custstub.c	stub file to replace get_cust.c */

/* Copyright (C) 1991, 1992 by FTP Software, Inc.  All rights reserved.
 * 
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 * 
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 * 
 * Edit History
 *  09-Jan-92	Ben	Created the stub file.
 *  13-Jul-92	Ben	Silence compiler warnings.
 */

#include <types.h>

#define FALL_THROUGH	2


int cust_seek(char *section, char *subsection, int flags)
{
    /* This should silence compiler warnings */
    section = section;
    subsection = subsection;
    flags = flags;
    
    return (FALL_THROUGH);	/* let config_seek() handle it */
}


int cust_read(char *name, int instance, char *value, int len, int flags)
{
    /* This should silence compiler warnings */
    name = name;
    instance = instance;
    value = value;
    len = len;
    flags = flags;

    return (FALL_THROUGH);	/* let config_seek() handle it */
}


int check_use_old_init(void)
{
    return (FALSE);		/* Don't use-old-init-scheme */
}

/*
 * $Log:   K:/21vcs/srclib/config/custstub.c_v  $
 * 
 *    Rev 1.1   13 Jul 1992 21:05:38   arnoff
 * Silence compiler warnings.   ---Ben
 * 
 *    Rev 1.0   30 Jan 1992 00:05:54   arnoff
 *  
 */
