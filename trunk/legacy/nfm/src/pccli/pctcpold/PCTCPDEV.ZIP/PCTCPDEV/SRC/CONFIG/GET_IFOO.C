/*
 * $Header:   K:/22vcs/srclib/config/get_ifoo.c_v   1.4   19 Nov 1992 17:49:40   seven  $
 */

/* get_ifoo.c	convert config_seek() and config_read() to use .sys file
 *		(In case you can't tell, this is a kludge (but good, I hope):)
 *
 * get_ifoo.c requires the presence of the libraries ?netlib.lib and ?pc.lib
 */

/* Copyright (C) 1991,1992 by FTP Software, Inc.  All rights reserved.
 * 
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 * 
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 * 
 * Edit History
 * 30-Dec-91	Ben	It's alive!
 * 02-Jan-92	Ben	Added ini table
 * 06-Jan-92	Ben	Added beginings of a case statement
 * 07-Jan-92	Ben	Added instance
 * 08-Jan-92	Ben	Added begining of ifcust and security stuff.
 *			Added subsection to seek.
 * 10-Jan-92	Ben	Implement ip-security ports
 * 13-Jan-92	Ben	converted local functions and structs to static.
 *			 Only return mininal ifcust information.
 * 14-Jan-92	Ben	Removed alloca (MSC doesn't like it for windows)
 *			 Include winapp.h for windows.  Call get_configstruct
 *			 Also include windows.h.  Replace lswap() and
 *			 inet_ntoa() with my own versions.  Added IP_TOS.
 * 15-Jan-92	Ben	Expanded basic security names.
 * 17-Jan-92	Ben	Mask non IP-TOS bits.  Split into seperate files
 * 21-Jan-92	Ben	Moved Paul's debug macro to get_cust.h
 * 18-Feb-92	Ben	Fixed userid/timezlabel typo
 * 13-May-92	paul	added function return types
 *			moved struct definitions to get_cust.h
 * 21-Jul-92	rcq	moved many hdr files to /include/pctcp (from /include)
 * 19-Nov-92	Ben	Fixed typo in debug message.
 */

#include <stdio.h>
#include <stdlib.h>
#include <types.h>
#include <string.h>

#ifdef WINDOWS
#include <windows.h>
#include <pctcp\winapp.h>	/* This needs to come before pctcp.h */
#endif

#include <pctcp/rwconf.h>
#include <pctcp/ipconfig.h>
#include <pctcp/ifconfig.h>
#include <pctcp/options.h>	/* for ip security()	*/

#include "get_cust.h"	/* Contains lots of defines */


/* IP precedence */

static struct	pr_tab	prec[] = {
	IP_PREC_ROUTINE,	"Routine",
	IP_PREC_PRIORITY,	"Priority",
	IP_PREC_IMMEDIATE,	"Immediate",
	IP_PREC_FLASH,		"Flash",
	IP_PREC_FLASH_OVERRIDE,	"Override",
	IP_PREC_CRITICECP,	"Critical/ECP",
	IP_PREC_INET_CONTROL,	"Internet-Control",
	IP_PREC_NET_CONTROL,	"Network-Control",
	-1, 0
};


/* This stuff is for IP Security (borrowed from trans.c) */

/* Basic Security class levels */
static struct	pr_tab	ip_bsec[] = {
	IP_TOPS,	"Top_secret",
	IP_SECR,	"Secret",
	IP_CONFI,	"Confidential",
	IP_UNCLA,	"Unclassified",
	-1, 0
};


/* Basic Security authority levels */
static struct	pr_tab	ip_auth[] = {
	AUTH_GENSER,	"GENSER",
	AUTH_SIOP,	"SIOP",
	AUTH_SCI,	"SCI",
	AUTH_NSA,	"NSA",
	AUTH_DOE,	"DOE",
	-1, 0
};


#if 0		/* never used */
/* This stuff is for drv_names (also borrowed from trans.c) */

/* Name of driver.sys files */
static struct	pr_tab	drv_names [] = {
	1, 	"3c500",
	1, 	"3c503",
	1, 	"3c505",
	1, 	"attnau",
	1, 	"bdnint",
	1, 	"dp839eb",
	1, 	"ethdrv",
	1, 	"ifcust",
	1, 	"ibmtr",
	1, 	"intel",
	1, 	"ni5010",
	1, 	"ni5210",
	1, 	"p1300",
	1, 	"p1340",
	1, 	"protint",
	1, 	"ppp",
	1, 	"slip",
	1, 	"scope",
	1, 	"ubnic",
	1, 	"wd8003",
	-1, 0
};
#endif		/* never used */

extern char	section_name[];
extern char	sub_section_name[];

/*
 * constant strings for booleans
 *		TRUE:				FALSE:	
 */

#if 0		/* never used */
static char	GC_TRUE[]	= "TRUE",	GC_FALSE[]	= "FALSE";
#endif		/* never used */

static char	GC_ON[]		= "ON",		GC_OFF[]	= "OFF";
static char	GC_HIGH[]	= "HIGH",	GC_LOW[]	= "LOW";
static char	GC_BS[]		= "BS",		GC_DEL[]	= "DEL";
static char	GC_STRICT[]	= "STRICT",	GC_LAX[]	= "LAX";


/*
 * Functions begin here...
 */

/*
 *  Return FALSE if couldn't read cust structure.
 *  Return TRUE  if okay.
 *  Return FALL_THROUGH	 if normal library should be used.
 */

int
get_ifc (struct vars *sp, char *value, int len, int flags)
{
    char driver[10];
    struct ifconfig ifc;

    /* Get the ifconfig structure */

    /* convert "driver" to "driver0" */
    strcpy (driver, section_name);
    strcat (driver, "0");
    
#ifdef WINDOWS
    if(!get_configstruct(driver, &ifc, sizeof (ifc))) 
#else
    if(!get_ifconfig(driver, &ifc)) 
#endif
    {
DEBUG (printf ("error on cust_read %s, couldn't find IFCUST\n", sp->name);)
	config_errno = CE_NO_CUST_FILE;
	return (FALSE);
    }

    /* The IFCUST half of a giant CASE statement */

    switch ((unsigned) sp->cust_name)
    {

 	case (BROADCAST):
	    return (convert_addr (ifc.c_broadcast, value, len));

 	case (IP_ADDR):
	    return (convert_addr (ifc.c_me, value, len));

 	case (NETMASK):
	    return (convert_addr (ifc.c_net_mask, value, len));

#if 0	/* These are to be ignored */
	case (BASE):
	    return (convert_number (ifc.c_base, value, len, 16));

 	case (DMA):
	    return (convert_boolean ((ifc.c_flags & FL_DMA), GC_ON, GC_OFF, value, len));
	    
	case (INT_VECT):
	    return (convert_number (ifc.c_intvec, value, len, 10));

	case (PORT):
	    return (convert_number (ifc.c_port, value, len, 10));

	case (MEMORY):
	    return (convert_number (ifc.c_memory, value, len, 16));

	case (RAM_SIZE):
	    return (convert_number (ifc.c_msize, value, len, 16));

	case (RCV_DMA):
	    if (ifc.c_flags & FL_DMA)
		return (convert_number (ifc.c_rcv_dma, value, len, 10));
	    else
		return (FALSE);

	case (XMT_DMA):
	    if (ifc.c_flags & FL_DMA)
		return (convert_number (ifc.c_tx_dma, value, len, 10));
	    else
		return (FALSE);
#endif      

	/* We don't know what to do with it, so try the ini file */
	default:
	{
	    return (FALL_THROUGH);
	}
    }
}  /* end of get_ifc() */

/* yes, I know -> 'flags' : unreferenced formal parameter */

int
get_ipc(struct vars *sp, int instance, char *value, int len, int flags)
{
    int	idx, count;
    struct ipconfig ipc;

    /* Get the ipconfig structure */

#ifdef WINDOWS
    if(!get_configstruct("$IPCUST", &ipc, sizeof (ipc))) 
#else
    if(!get_ipconfig("$IPCUST", &ipc)) 
#endif
    {
DEBUG (printf ("error on cust_read %s, couldn't find IPCUST\n", name);)
	config_errno = CE_NO_CUST_FILE;
	return (FALSE);
    }

    /* The IPCUST half of a giant CASE statement */

    switch ((unsigned) sp->cust_name)
    {
	/* The IPCUST half of the array */
 	case (DOMAIN):
	    return (convert_string (ipc.c_domain, value, len));

	case (DS):
	    return (convert_addr_array (ipc.c_dm_servers,ipc.c_numdname,
		instance, value, len));
	    
	case (EMULATOR_ARROW):
	    if  (len < 4)
	    {
		config_errno = CE_OVERFLOW;
		return (FALSE);
	    }
	    return (convert_boolean ((ipc.c_emulators & EM_BS),
		    GC_BS, GC_DEL, value, len));

	case (EMULATOR_WRAP):
	    return (convert_boolean ((ipc.c_emulators & EM_WRAP),
		    GC_ON, GC_OFF, value, len));

 	case (FULLNAME):
	    return (convert_string (ipc.c_domain, value, len));

        case (GW):
	    return (convert_addr (ipc.c_defgw, value, len));
	    
	case (HOSTNAME):
	    return (convert_string (ipc.c_hostname, value, len));

	case (HOSTTABLE):
	    return (convert_string (ipc.c_hosttable, value, len));

 	case (IP_PREC):
	    for (idx = 0; prec[idx].val != -1; idx++) 
	    {
		/* Mask bit 0-2 for precedence */
		if (prec[idx].val == (ipc.c_ip_tos & IP_PREC_MASK))
		    return (convert_string (prec[idx].name, value, len));
	    }
	    return (FALSE);	/* Unknown precedence setting */

	case (IP_PREC_MATCH):
	    return (convert_boolean ((ipc.c_ip_opt_flag & C_IP_STRICT),
		    GC_STRICT, GC_LAX, value, len));

	case (IP_TOS):
	    return (convert_number ((ipc.c_ip_tos & IP_TOS_MASK), value, len, 16));

	case (IP_TOS_DELAY):
	    return (convert_boolean ((ipc.c_ip_tos & IP_TOS_LOW_DELAY), 
		    GC_LOW, GC_HIGH, value, len));

	case (IP_TOS_RELI):
	    return (convert_boolean ((ipc.c_ip_tos & IP_TOS_HIGH_RELIABILITY),
		    GC_HIGH, GC_LOW, value, len));

	case (IP_TOS_THRU):
	    return (convert_boolean ((ipc.c_ip_tos & IP_TOS_HIGH_THROUGHPUT),
		    GC_HIGH, GC_LOW, value, len));

	case (IP_TOS_COST):
	    return (convert_boolean ((ipc.c_ip_tos & IP_TOS_LOW_COST), GC_LOW,
		    GC_HIGH, value, len));

	case (MAILRELAY):
	    return (convert_string (ipc.c_mailrelay, value, len));

 	case (OFFICE):
	    return (convert_string (ipc.c_office, value, len));

 	case (PHONE):
	    return (convert_string (ipc.c_phone, value, len));

	case (SERVER_LOG):
	case (SERVER_COOKIE):
	case (SERVER_LPR):
	case (SERVER_IPRINT):

	    /* Figure out offset in servers array from difference of switch */
	    /* (we're assuming that the order will NEVER change) */
	    count = sp->cust_name - SERVER_LOG;

	    if (ipc.c_servers[count] == 0)
	    {
		config_errno = CE_ENTRY;
		return (FALSE);
	    }

	    return (convert_addr (ipc.c_servers[count], value, len));

	/* Basic option is |type-0x82|len|class|auth|
	 *   len includes itself and type
	 */
	    
	case (SECURITY_BASIC_AUTH):  
	    /* Is basic security off? */
	    if ((ipc.c_ip_opt_flag & C_IP_BAS) == FALSE)
	    {
		config_errno = CE_ENTRY;
		return (FALSE);
	    }

	    /* Search through basic security list to find authority */
	    for (idx = 0; ip_auth[idx].val != -1; idx++) 
	    {
		if (ip_auth[idx].val == ipc.c_ip_options[ipc.c_bas_security+3])
		    return (convert_string (ip_auth[idx].name, value, len));
	    }
	    return (TRUE);

	case (SECURITY_BASIC_CLASS): 
	    /* Is basic security off? */
	    if ((ipc.c_ip_opt_flag & C_IP_BAS) == FALSE)
	    {
		config_errno = CE_ENTRY;
		return (FALSE);
	    }

 	    /* search through basic security list to find class */
	    for (idx = 0; ip_bsec[idx].val != -1; idx++) 
	    {
		if (ip_bsec[idx].val == ipc.c_ip_options[ipc.c_bas_security+2])
		    return (convert_string (ip_bsec[idx].name, value, len));
	    }
	    return (FALSE);	/* unknown security setting */

	/* Extend option is |type-0x85|len|byte0|...|byteN| 
	 *   len includes itself and type
	 */

	case (SECURITY_EXTENDED):    
	    /* Is basic security off?  Is extended security off? */
	    if (((ipc.c_ip_opt_flag & C_IP_BAS) == FALSE) ||
		((ipc.c_ip_opt_flag & C_IP_EXT) == FALSE))
	    {
		config_errno = CE_ENTRY;
		return (FALSE);
	    }
	    else
	    {
		char	ext_buf[16];
		int	ext_byte, ext_idx, ext_len, len_left;

		ext_idx = ipc.c_ext_security;
		ext_idx++;	/* skip type */

		/* get len of extend option, skip type & len */
		ext_len = ipc.c_ip_options[ext_idx++] - 2; 
		if (ext_len == 0)
		    return (FALSE);

		len_left = len;
		
		value[0] = '\0';	/* make strcat() happy */

		while ((ext_len > 0) & (len_left > 0))
		{
		    /* Add bytes to value as hex numbers */
		    ext_byte = ipc.c_ip_options[ext_idx];
		    if (convert_number (ext_byte, ext_buf, len_left, 16) == FALSE)
			return (FALSE);
		    strcat (value, ext_buf);
		    strcat (value, " ");

		    /* Figure out how many bytes are left */
		    len_left = len - strlen (value);

		    /* Advance to the next byte */
		    ext_len--;
		    ext_idx++;
		}
		return (TRUE);
	    }
/* Warning get_ifoo.c 425: Unreachable code in function get_ipc */
	    break;

	case (SECURITY_MATCHING):    
	    /* Is basic security off? */
	    if ((ipc.c_ip_opt_flag & C_IP_BAS) == FALSE)
	    {
		config_errno = CE_ENTRY;
		return (FALSE);
	    }

	    return (convert_boolean ((ipc.c_ip_opt_flag & C_IP_SECURE),
		    GC_STRICT, GC_LAX, value, len));

	case (SECURITY_PORTS):	      
	{
	    int		idx, offset;
	    in_name	addr;
	    unsbyte	mask;

	    /* Is basic security off?  Are there any ports set? */
	    if (((ipc.c_ip_opt_flag & C_IP_BAS) == FALSE) ||
		(ipc.c_ip_opt_numports == 0))
	    {
		config_errno = CE_ENTRY;
		return (FALSE);
	    }

	    value[0] = '\0';	/* Don't confuse strlen */
	    
	    /* assemble a list of ip addresses for the ports */
	    for (idx = 0; idx < ipc.c_ip_opt_numports; idx++)
	    {
		offset = strlen (value);

//		strcat (value, "~");		
		/* Find port info */
		addr = ipc.c_ip_opt_port[idx].port;
		mask = ipc.c_ip_opt_port[idx].msk;

		if (convert_port (addr, mask, (value+offset), (len-offset)) == FALSE)
		    return (FALSE);

		/* Add a bit of white space, if needed */
		if ((idx+1) < ipc.c_ip_opt_numports)
		    strcat (value, " ");
	    }

	    return (TRUE);
	}
	    
	/* These two variable are close enough that they use 
	 *   the same function */
	case (SECURITY_PORTS_RCV):   
	case (SECURITY_PORTS_XMT):   
	    /* Is basic security off?  Are there any ports set? */
	    if (((ipc.c_ip_opt_flag & C_IP_BAS) == FALSE) ||
		(ipc.c_ip_opt_numports == 0))
	    {
		config_errno = CE_ENTRY;
		return (FALSE);
	    }

	    return (port_options (sp->name, sub_section_name, &ipc, value, len));
	    
	case (SECURITY_SETTING):
	    /* Is basic security off? */
	    if ((ipc.c_ip_opt_flag & C_IP_EXT) == FALSE)
		return (convert_string ("EXTENDED", value, len));

	    else if ((ipc.c_ip_opt_flag & C_IP_BAS) == TRUE)
		return (convert_string ("BASIC", value, len));

	    else
		return (convert_string ("NONE", value, len));

 	case (TMLABEL):
	    return (convert_string (ipc.c_tmlabel, value, len));

 	case (TMOFFSET):
	    return (convert_number (ipc.c_tmoffset, value, len, 10));

	case (TS):
	    return (convert_addr_array (ipc.c_time, ipc.c_numtime, 
		instance, value, len));
	    
 	case (USERID):
	    return (convert_string (ipc.c_userid, value, len));

 	case (WINDOW):
	    return (convert_number (ipc.c_window, value, len, 10));

 	case (WINDOW_LOW):
	    return (convert_number (ipc.c_lowwindow, value, len, 10));

	/* We don't know what to do with it, so try the ini file */
	default:
	    return (FALL_THROUGH);
    }
}  /* end of get_ipc() */

/* yes, I know -> 'flags' : unreferenced formal parameter */


/*
 * $Log:   K:/22vcs/srclib/config/get_ifoo.c_v  $
 * 
 *    Rev 1.4   19 Nov 1992 17:49:40   seven
 * Fixed typo in debug message.
 * 
 *    Rev 1.3   14 Sep 1992 16:07:48   paul
 *  * 21-Jul-92	rcq	moved many hdr files to /include/pctcp (from /include)
 * 
 *    Rev 1.2   13 May 1992 11:53:26   paul
 * added function return types
 * move struct definitions to get_cust.h
 * updated copyright notice
 * 
 *    Rev 1.1   18 Feb 1992 16:47:48   arnoff
 * Fixed userid tmlabel typo
 * 
 *    Rev 1.0   30 Jan 1992 00:06:06   arnoff
 *  
 */
