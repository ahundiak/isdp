/* 
 * $Header:   J:/22vcs/srclib/rpc4/s_run.c_v   1.0   10 Nov 1992 22:58:06   rcq  $
 */
#define FTP /*Copyright 1992, FTP Software, Inc.  All Rights Reserved.*/
#ifdef FTP /* added code */
/*
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 * 
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 *
 * (Edit history is maintained in RCS archives.)
 */
#else /* FTP superceded code */
/* @(#)svc_run.c	2.1 88/07/29 4.0 RPCSRC */
#if !defined(lint) && defined(SCCSIDS)
static char sccsid[] = "@(#)svc_run.c 1.1 87/10/13 Copyr 1984 Sun Micro";
#endif

/*
 * Sun RPC is a product of Sun Microsystems, Inc. and is provided for
 * unrestricted use provided that this legend is included on all tape
 * media and as a part of the software program in whole or part.  Users
 * may copy or modify Sun RPC without charge, but are not authorized
 * to license or distribute it to anyone else except as part of a product or
 * program developed by the user.
 * 
 * SUN RPC IS PROVIDED AS IS WITH NO WARRANTIES OF ANY KIND INCLUDING THE
 * WARRANTIES OF DESIGN, MERCHANTIBILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, OR ARISING FROM A COURSE OF DEALING, USAGE OR TRADE PRACTICE.
 * 
 * Sun RPC is provided with no support and without any obligation on the
 * part of Sun Microsystems, Inc. to assist in its use, correction,
 * modification or enhancement.
 * 
 * SUN MICROSYSTEMS, INC. SHALL HAVE NO LIABILITY WITH RESPECT TO THE
 * INFRINGEMENT OF COPYRIGHTS, TRADE SECRETS OR ANY PATENTS BY SUN RPC
 * OR ANY PART THEREOF.
 * 
 * In no event will Sun Microsystems, Inc. be liable for any lost revenue
 * or profits or other special, indirect and consequential damages, even if
 * Sun has been advised of the possibility of such damages.
 * 
 * Sun Microsystems, Inc.
 * 2550 Garcia Avenue
 * Mountain View, California  94043
 */
#endif /* FTP */

/*
 * This is the rpc server side idle loop
 * Wait for input, call server program.
 */
#ifdef FTP /* added code */
#include <rpc/rpc.h>
#include <stdio.h>
#include <errno.h>
#include <rpc/pmap_cln.h>
#include <4bsddefs.h> /* for select */
#include <sys/time.h>
#include <sys/types.h>

#else /* FTP superceded code */
#include <rpc/rpc.h>
#include <sys/errno.h>
#endif /* FTP */

#ifdef FTP /* added code */
void
#ifndef MSDOS
_DLL_FLAGS
#endif
svc_run(void)
#else /* FTP superceded code */
void
svc_run()
#endif /* FTP */
{
#ifdef FD_SETSIZE
	fd_set readfds;
#else
#ifdef FTP /* added code */
	unsigned long readfds;
#else /* FTP superceded code */
      int readfds;
#endif /* FTP */
#endif /* def FD_SETSIZE */
#ifdef FTP /* added code */
	struct timeval t;	/* Time out select for keyboard check */
#else /* FTP superceded code */
	extern int errno;
#endif /* FTP */

#ifdef FTP /* added code */
	t.tv_sec = 1;			/* Make the check every second */
	t.tv_usec = 0;			/*  (nothing else to do...) */
#endif /* FTP */
	for (;;) {
#ifdef FD_SETSIZE
		readfds = svc_fdset;
#else
		readfds = svc_fds;
#endif /* def FD_SETSIZE */
#ifdef FTP /* added code */
		/* In DOS, do explicit check on keyboard, print help. */
		switch (select(_rpc_dtablesize(), &readfds, (long *)0,
			(long *)0, &t)) {
		case -1:
			if (errno == EINTR) {
				continue;
			}
			perror("svc_run: - select failed");
			return;
		case 0:
			if (kbhit()) {
				switch (getche()) {
				case 'q':
					puts("RPC server exit requested");
					net_releaseall();	/* Cleanup */
					return;
				case '?':
				case 'h':
				default:
					puts("RPC server: 'q' to quit");
					break;
				}
			}
			continue;
		default:
			svc_getreqset(&readfds);
		}
#else /* FTP superceded code */
		switch (select(_rpc_dtablesize(), &readfds, (int *)0, (int *)0,
			       (struct timeval *)0)) {
		case -1:
			if (errno == EINTR) {
				continue;
			}
			perror("svc_run: - select failed");
			return;
		case 0:
			continue;
		default:
			svc_getreqset(&readfds);
		}
#endif /* FTP */
	}
}
/* 
 * $Log:   J:/22vcs/srclib/rpc4/s_run.c_v  $
 * 
 *    Rev 1.0   10 Nov 1992 22:58:06   rcq
 * Initial revision.
 */