/*
 * $Header:   H:/22vcs/srclib/config/convert.c_v   1.3   14 Sep 1992 16:07:32   paul  $
 */

/* get_cust.c	convert config_seek() and config_read() to use .sys files
 *		(In case you can't tell, this is a kludge (but good, I hope):)
 *
 * get_cust.c requires the presence of the libraries ?netlib.lib and ?pc.lib
 */

/* Copyright (C) 1991,1992 by FTP Software, Inc.  All rights reserved.
 * 
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 * 
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 * 
 * Edit History
 * 30-Dec-91	Ben	It's alive!
 * 02-Jan-92	Ben	Added ini table
 * 06-Jan-92	Ben	Added beginings of a case statement
 * 07-Jan-92	Ben	Added instance
 * 08-Jan-92	Ben	Added begining of ifcust and security stuff.
 *			Added subsection to seek.
 * 10-Jan-92	Ben	Implement ip-security ports
 * 13-Jan-92	Ben	converted local functions and structs to static.
 *			 Only return mininal ifcust information.
 * 14-Jan-92	Ben	Removed alloca (MSC doesn't like it for windows)
 *			 Include winapp.h for windows.  Call get_configstruct
 *			 Also include windows.h.  Replace lswap() and
 *			 inet_ntoa() with my own versions.  Added IP_TOS.
 * 15-Jan-92	Ben	Expanded basic security names.
 * 17-Jan-92	Ben	Mask non IP-TOS bits.  Split into seperate files.
 * 21-Jan-92	Ben	Moved Paul's debug macro to get_cust.h
 * 10-Feb-92	paul	added function return types
 * 11-Feb-92	paul	move struct definitions to get_cust.h
 * 17-Jun-92	jbvb	Don't call in MSC long division stuff.
 * 18-Jun-92	jbvb	Correct maximum size of long to 10 digits.
 * 21-Jul-92	rcq	changed to <rwconf.h> and <ipconfig.h> to 
 *			<pctcp/rwconf.h> and <pctcp/ipconfig.h>
 */

#include <stdio.h>
#include <stdlib.h>
#include <types.h>
#include <string.h>
#include <ctype.h>		/* tolower */

#ifdef WINDOWS
#include <windows.h>
#include <pctcp\winapp.h>	/* This needs to come before pctcp.h */
#endif

#include <pctcp/ipconfig.h>	/* for struct ipconfig	*/
#include <sys/types.h>		/* for u_short & u_char */
#include <netinet/in.h>		/* for in_addr		*/
#include <pctcp/pctcp.h>
#include <pctcp/options.h>	/* for security stuff	*/
#include <pctcp/rwconf.h>

#include "get_cust.h"	/* Contains lots of defines */

/* This stuff is for IP Security (borrowed from trans.c) */

/* Basic Security class levels */
static struct	pr_tab	ip_bsec[] = {
	IP_TOPS,	"Top_secret",
	IP_SECR,	"Secret",
	IP_CONFI,	"Confidential",
	IP_UNCLA,	"Unclassified",
	-1, 0
};

static char	GC_TRUE[]	= "TRUE",	GC_FALSE[]	= "FALSE";

extern int	next_instance;

/*
 * Functions begin here...
 */

/* return options for a port */

int
port_options (char name[], char *port, struct ipconfig *ipc, char *value, int len)
{
    char	*tmp_ptr;
    int		idx, offset;
    in_name	addr;
    struct opt_port	*opt_ptr;
        
    /* convert wildcard characters to '0' */
    tmp_ptr = port;
    while (*tmp_ptr != '\0')
    {
	if ((*tmp_ptr == 'X') || (*tmp_ptr == 'x') || (*tmp_ptr == '*'))
	    *tmp_ptr = '0';
	tmp_ptr++;
    }
    
    /* Convert port into an IP addr */
    addr = nm_prs_addr (port);    

    /* Find port info */
    for (idx = 0; idx < ipc->c_ip_opt_numports; idx++)
    {
	/* Did we find a match? */
	if (ipc->c_ip_opt_port[idx].port == addr)
	{
	    opt_ptr = &(ipc->c_ip_opt_port[idx]);
	    break;
	}
    }

    /* if we made it to the end of the list, then there wasn't a match */
    if (idx == ipc->c_ip_opt_numports)
    {
	config_errno = CE_ENTRY;
	return (FALSE);
    }
	    
    /* Was the request for transmit or received information? */
    if (tolower (name[0]) == 't')
	/* Look for transmit settings */
	return (convert_boolean((opt_ptr->trn),GC_TRUE,GC_FALSE, value, len));
    else
    {
	convert_boolean((opt_ptr->rcv),GC_TRUE,GC_FALSE, value, len);
	if (opt_ptr->rcv == TRUE)
	{
	    return (convert_string (GC_TRUE, value, len));
	}
	else
	{
	    if (convert_string (GC_FALSE, value, len) == FALSE)
		return (FALSE);

	    offset = strlen(value) + 1;
	    if (offset >= len)
	    {
		config_errno = CE_OVERFLOW;	
		return (FALSE);		
	    }
	    strcat (value, " ");

 	    /* search through basic security list to find class */
	    for (idx = 0; ip_bsec[idx].val != -1; idx++) 
	    {
		if (ip_bsec[idx].val == ipc->c_ip_options[ipc->c_bas_security+2])
		    return (convert_string (ip_bsec[idx].name, value+offset, len-offset));
	    }
	    return (FALSE);
	}
    }
}  /* end of port_options() */


/*
 * These are simple routines for converting the info from
 * the i[f/p]config structure to strings.
 */

int
convert_string (char *string, char *value, int len)
{
    if (strlen (string) > (unsigned)(len + 1))
    {
	config_errno = CE_OVERFLOW;	
	return (FALSE);		
    }				
    
    if (strlen (string) == 0)	
    {				
	config_errno = CE_ENTRY;
	return (FALSE);		
    }				
    
    strncpy (value, string, len);
    value[len-1] = '\0';		
    return (TRUE);					

}  /* end of convert_string () */


int
convert_number (unsigned number, char *value, int len, int radix)
{
    char	tmp_buf[16];

    /* Are there too many digits? */
    if ((number_size ((long)number)+2) >= len)
    {
	config_errno = CE_OVERFLOW;
	return (FALSE);
    }
    
    /* make sure that strcat doesn't get confused */
    value[0] = '\0';  

    /* Convert the number a string, in the appropriate base */
    itoa (number, tmp_buf, radix);

    /* Add the appropriate prefix to the number */
    if (radix == 16)
	strcpy (value, "0x");
    else if (radix == 8)
	strcpy (value, "0");

    strcat (value, tmp_buf);
	
    value[len-1] = '\0';
    return (TRUE);

}  /* end of convert_number () */


int
convert_long (unsigned long number, char *value, int len, int radix)
{
    char	tmp_buf[16];

    /* Are there too many digits? */
    if ((number_size (number)+2) >= len)
    {
	config_errno = CE_OVERFLOW;
	return (FALSE);
    }
    
    /* make sure that strcat doesn't get confused */
    value[0] = '\0';  

    /* Convert the number a string, in the appropriate base */
    ltoa (number, tmp_buf, radix);

    /* Add the appropriate prefix to the number */
    if (radix == 16)
	strcpy (value, "0x");
    else if (radix == 8)
	strcpy (value, "0");

    strcat (value, tmp_buf);
	
    value[len-1] = '\0';
    return (TRUE);

}  /* end of convert_number () */


int
convert_addr (in_name addr, char *value, int len)
{
    struct in_addr in;
    
    in.s_addr = addr;

    if (len < 16)
    {
	config_errno = CE_OVERFLOW;
	return (FALSE);
    }
    
#ifdef WINDOWS
    wsprintf(value, "%d.%d.%d.%d", in.s_net, in.s_host, in.s_lh, in.s_impno);
#else
    sprintf(value, "%d.%d.%d.%d", in.s_net, in.s_host, in.s_lh, in.s_impno);
#endif
    return (TRUE);

}  /* end of convert_addr () */


int
convert_addr_array (in_name addrs[], int max, int inst, char *value, int len)
{
    if ((max == 0) || (next_instance >= max) || (inst >= (signed) max))
    {
	config_errno = CE_ENTRY;
	return (FALSE);
    }
    
    if (inst != -1)
	next_instance = inst;

    return (convert_addr (addrs [next_instance++], value, len));
}  /* end of convert_addr_array () */


int
convert_port (in_name addr, unsbyte mask, char *value, int len)
{
    char	tmp_buf[16];
    int		i;
    struct in_addr in;
    unsigned	number;
    u_short	tmp;
    
    if (mask == 0)
	return (convert_addr (addr, value, len));

    /* else convert masked '0' to '*' */

    if (len < 16)
    {
	config_errno = CE_OVERFLOW;
	return (FALSE);
    }
    
/* Put the bytes in to network order  (to quote lswap.asm...) 
 *
 *    ... bytes 0 and 3 swapped, bytes 1 and 2 swapped
 *    And the last shall be first, and the first, last...
 *
 *	(instead of lswap (addr))
 */

    in.s_addr = addr;

    tmp = in.S_un.S_un_b.s_b1;
    in.S_un.S_un_b.s_b1 = in.S_un.S_un_b.s_b4;
    in.S_un.S_un_b.s_b4 = tmp;

    tmp = in.S_un.S_un_b.s_b2;
    in.S_un.S_un_b.s_b2 = in.S_un.S_un_b.s_b3;
    in.S_un.S_un_b.s_b3 = tmp;

    addr = in.s_addr;
    
    /* Start at the big end */
    for (i = 3; i >= 0; i--)
    {
	if ((mask >> i) & 0x01)
	{
	    /* Replace masked value with a '*' */
	    strcat (value, "*");
	}
	else	
	{
	    /* get one byte at a time */
	    number = (unsigned) ((addr >> (i*8)) & 0x000000ff);
	    strcat (value, itoa (number, tmp_buf, 10));
	}

	/* add a dot, if needed */
	if (i > 0)
	    strcat (value, ".");
    }
    
    return (TRUE);
}  /* end of convert_port () */


/* This function is passed the results of a boolean expression, and it
 * will write the appropriate string to value, depending upon the results
 */

int
convert_boolean (int bool, char true_str[], char false_str[], char *value, int len)
{
    /* If the string to be outputed is too long, punt */
    if ((strlen (true_str) >= (unsigned)len) || 
	(strlen (false_str) >= (unsigned)len))
    {
	config_errno = CE_OVERFLOW;
	return (FALSE);
    }
    
    if (bool == TRUE)
	strcpy (value, true_str);
    else
	strcpy (value, false_str);

    return (TRUE);
}  /* end of convert_boolean () */


/* Return how many characters will be needed to store 'number in a string.
 *
 * 'number' must be positive as it is presently implemented.
*/
int number_size (long number)
{
    if ((unsigned long)number < 10)
	return (1);
    else if (number < 100)
	return 2;
    else if (number < 1000)
	return 3;
    else if (number < 10000)
	return 4;
    else if (number < 100000L)
	return 5;
    else if (number < 1000000L)
	return 6;
    else if (number < 10000000L)
	return 7;
    else if (number < 100000000L)
	return 8;
    else if (number < 1000000000L)
	return 9;
    return 10;			/* As big as a long can be */
}  /* end of number_size() */


/*
 * $Log:   H:/22vcs/srclib/config/convert.c_v  $
 * 
 *    Rev 1.3   14 Sep 1992 16:07:32   paul
 *  * 21-Jul-92	rcq	changed to <rwconf.h> and <ipconfig.h> to 
 *  *			<pctcp/rwconf.h> and <pctcp/ipconfig.h>
 * 
 *    Rev 1.2   24 Jun 1992 15:39:10   paul
 * track changes from 2.1
 * 
 *    Rev 1.1   13 May 1992 11:53:08   paul
 * added function return types
 * movee struct definitions to get_cust.h
 * updated copyright notice
 * 
 *    Rev 1.0   30 Jan 1992 00:05:48   arnoff
 *  
 */
