/*
 * $Header:   K:/22vcs/srclib/config/conf.c_v   1.17   09 Nov 1992 14:40:18   seven  $
 */

/* conf.c	open, seek, read, close operations on config file.
 */

/* Copyright (C) 1991,1992 by FTP Software, Inc.  All rights reserved.
 * 
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 * 
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 * 
 * Edit History
 * 23-Jun-91	rehmi	this is intended to replace the guts of getconf() and
 *			getwild(); gordon's handwaving inspired this.
 * 24-Jun-91	rehmi	added config_errno and put in error codes.
 * 15-Jul-91	gordon	Made config_read return CE_PARM_ERROR on NULL name
 * 15-Jul-91	gordon	Made config_read set config_errno to CE_OK by default
 * 15-Jul-91	Ben	Fixed up for compiler (-W3)
 * 31-Jul-91	rehmi	added tabs to whitespace, minor fixes.
 * 13-Sep-91	rehmi	added field extension by carrying field name over \n
 * 14-Oct-91	jog	added windows.h and the MessageBox call.
 * 15-Oct-91	jog	added warning_done flag so only do it once...
 * 24-Oct-91	rehmi	warning_done should be static to its static function.
 * 31-Dec-91	Ben	Added hooks for use-old-init-scheme
 * 08-Jan-91	Ben	Updated cust_seek prototype.
 * 16-Jan-92	paul	made config_filename, _config_last_offset static
 * 16-Jan-92	Ben	Changed fopens to sopen/fdopen
 * 21-Jan-92	Ben	If we can't find a continuation file, ignore it.
 *			 Added Paul's DEBUG macro.
 * 17-Feb-92	Ben	Try speeding up config_seek() & config_read().  Reuse
 *			 last config_seek position if same seek.  If previous
 *			 seek for same section failed, don't seek again.
 * 25-Feb-92	Ben	Don't rewind if config_read is looking for "".
 * 27-Feb-92	Ben	rewind in config_read, if instance is set.
 * 09-Mar-92	Ben	Convert '_' to '-' for internal use in config_read.
 * 22-Mar-92	Ben	Renamed warning_done to config_warning_done, and 
 *			 changed it from a static to a global.
 * 26-Mar-92	Ben	Save _last_section if config_seek failed.
 * 27-Mar-92	Ben	Fix up continuation file handling. Changed 
 *			 config_open() to open file, if different.
 * 29-Mar-92	Ben	Fixed bug introduced in config_open().
 * 30-Mar-92	Ben	Remove trailing white space (unless wanted).  More 
 *			 work on config_open().
 * 07-May-92	Ben	Replaced a return with a goto in config_read().
 * 13-May-92	paul	added mode argument to sopen call to satisfy TurboC
 * 21-Jul-92	rcq	changed to <rwconf.h> to <pctcp/rwconf.h>
 * 04-Nov-92	Ben	Check if the INI file is open before running
 *			 config_seek() Check if config_seek() was called
 *			 before running config_read().
 * 06-Nov-92	Ben	Replaced two bits of duplicate code with gotos to a
 *			 third.
 * 09-Nov-92	Ben	Check if current file is the continuation file before
 *			 trying to open a new continuation file.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>		/* for isspace() */
#include <share.h>		/* for sopen's settings */
#include <fcntl.h>
#include <io.h>			/* for access	*/

#ifdef WINDOWS
#include <windows.h>
#else
#define TRUE			(0==0)
#define FALSE			(!TRUE)
#include <conio.h>		/* for putch 	*/
#endif

#include <pctcp/rwconf.h>

#if defined(DEBUG) && !defined(WINDOWS)
#undef DEBUG
#define DEBUG(x) x
#else
#undef DEBUG
#define DEBUG(x)
#endif


/* turn old '_' into new '-' */		

#define CONVERT_DASHES(string)			\
{						\
    char  *cp;					\
						\
    for (cp = string; *cp; cp++)		\
    	if (*cp == '_')				\
	    *cp = '-';				\
}


#define STRSAME(a,b)		(stricmp(a,b)==0)

FILE *_config_FILE = (FILE *) 0;	/* pctcp.ini file	*/
FILE *_cont_FILE = (FILE *) 0;		/* continuation file	*/
FILE *_curr_FILE = (FILE *) 0;		/* current file pointer	*/

char *_config_wildcard = "";
char *_config_pctcp_package = "pctcp";
char *_config_token_delimiter = " \t\n=]";
int config_errno = CE_OK;
int use_old_init = -1;

//static char *_config_filename = NULL;
static char _config_filename [128] = {""};
static long _config_last_offset = -1L;

static char _last_package [MAX_SECTION_LEN+1] = {""};
static char _last_section [MAX_SECTION_LEN+1] = {""};
static char _last_subsection [MAX_SECTION_LEN+1] = {""};

static int  called_config_seek = FALSE;

/* These are only called in here */

/* GET_CUST.C */
int cust_seek(char *section, char *subsection, int flags);
int cust_read(char *name, int instance, char *value, int len, int flags);
int check_use_old_init(void);


/* 
 * i just realized that one can use something like
 *
 *      config_open ("/config.sys", 0);
 *      config_read ("device", CONF_ANY_INSTANCE, buf, sizeof(buf), 0);
 *      config_read ("device", CONF_ANY_INSTANCE, buf, sizeof(buf), 0);
 *
 * and so on to read "device" lines in config.sys...  - rehmi
 */

/* see rwconf.h for function descriptions and prototypes.
 */

char _config_warning_done = 0;

#ifndef WINDOWS
static void
our_cputs (char *p)
{
    if (_config_warning_done)
	return;
    _config_warning_done = 1;

    while (p && *p) {
	if (*p == '\n')
	    putch('\r');
	    putch(*(p++));
    }
}
#else
static void
our_cputs(char *p)
{
    if (_config_warning_done)
	return;
    _config_warning_done = 1;

    MessageBox(NULL, p, "PC/TCP Configuration Library", MB_ICONEXCLAMATION | MB_OK);
}
#endif

#define PCTCP_WARNING \
	"Please convert FTP_CONFIG (in your environment) to PCTCP.\n"

int 
config_open (char *name, int flags)
/* ignore -> warning C4100: 'flags' : unreferenced formal parameter */
{
    int	fh;
    
    /* Initialize the various variables */
    _config_last_offset = -1L;
    _last_package[0] = '\0';
    _last_section[0] = '\0';
    _last_subsection[0] = '\0';
    config_errno = CE_OK;
    _curr_FILE = (FILE *) 0;
    called_config_seek = FALSE;

    if (_config_FILE) {
	if (STRSAME (name, _config_filename)) {
	    _curr_FILE = _config_FILE;
	    return (TRUE);
	}
	else {  /* It's a different file, open the new file */
	    if (_config_FILE != (FILE *) 0) {
		fclose(_config_FILE);
		_config_FILE = (FILE *) 0;
	    }
	    
	    if (_cont_FILE != (FILE *) 0) {
		fclose(_cont_FILE);
		_cont_FILE = (FILE *) 0;
	    }
	}
    }

    /* If name is NULL, use it as a temp pointer to find the INI file */
    if ((name == NULL) && ((name = getenv("PCTCP")) == NULL)) {
        if (name = getenv("FTP_CONFIG")) {
	    our_cputs(PCTCP_WARNING);
	} else if (access("pctcp.ini", 4) == -1) {
	    config_errno = CE_ENV;
	    return (FALSE);
	}
    }
    
    /* Save the name of the INI file */
    if (name == NULL)
	strcpy (_config_filename, "pctcp.ini");
    else
	strcpy (_config_filename, name);

    if (((fh = sopen(_config_filename, (O_RDONLY | O_TEXT), SH_DENYWR, 0)) == -1) ||
	((_config_FILE = fdopen(fh, "rt")) == (FILE *) 0)) {
	config_errno = CE_FILE;
	return (FALSE);
    }

    _curr_FILE = _config_FILE;
    return (TRUE);
}  /* end of config_open() */


int
config_close (int flags)
/* ignore -> warning C4100: 'flags' : unreferenced formal parameter */
{
    if (_config_FILE != (FILE *) 0) {
	fclose(_config_FILE);
        _config_FILE = (FILE *) 0;
    }

    if (_cont_FILE != (FILE *) 0) {
	fclose(_cont_FILE);
        _cont_FILE = (FILE *) 0;
    }

    /* Reset pointers */
    _curr_FILE = (FILE *) 0;

    _config_last_offset = -1L;
    _last_package[0] = '\0';
    _last_section[0] = '\0';
    _last_subsection[0] = '\0';
    config_errno = CE_OK;
    _config_filename[0] = '\0';
    called_config_seek = FALSE;

    return TRUE;
}  /* end of config_close() */


int
config_seek (char *package, char *section, char *subsection, int flags)
{
    char *ptok, *stok, *sstok, *tok;
    char buf[200], *bufp;
    int	 cfh, ret;
    
    /* Return an error if the INI file is closed */
    if (_config_FILE == (FILE *) 0) {
	config_errno = CE_FILE_NOT_OPEN;
	return (FALSE);
    }

    if (!package || !section) {
	config_errno = CE_PARM_ERROR;
	return (FALSE);
    }

    config_errno = CE_OK;

    if (flags != (int)SKIP_OLD_INIT) {
	if (use_old_init == -1) {
	    char	save_sect [MAX_SECTION_LEN];
	    long	save_offset;

	    /* save old values */
	    strncpy (save_sect, _last_section, MAX_SECTION_LEN);
	    save_offset = _config_last_offset;
		
	    use_old_init = check_use_old_init();

	    /* restore */
	    strcpy ( _last_section, save_sect);
	    _config_last_offset = save_offset;
	}
    
	if (use_old_init && (stricmp (package, "pctcp") == 0)) {
	    ret = cust_seek (section, subsection, flags);
	    if ((ret == FALSE) || (ret == TRUE))
		return (ret);
	    /* else fall through */
	}
    }

    if (flags & CONF_REWIND) {
	goto conf_rewind;
    } 
    else if ((flags & (CONF_SAME_SECTION|CONF_NEXT_SECTION))
	&& (_config_last_offset >= 0L)) {
 	fseek (_curr_FILE, _config_last_offset, 0);
	/* Return if NEXT not set */
	if (!(flags & CONF_NEXT_SECTION))
	    return (TRUE);
    }
    /* If we recently seeked to the same spot, reuse it */
    else if (*package && STRSAME (package, _last_package) &&
	     *section && STRSAME (section, _last_section)) {
	/* If there is a subsection check that it matches */
	if (!subsection || STRSAME (subsection, _last_subsection)) {
	    /* Don't parse the file, if we already found the section */
	    if (_config_last_offset != -1) {
		fseek (_curr_FILE, _config_last_offset, 0);
		return (TRUE);
	    }
	    else {
		config_errno = CE_SECTION;
		return (FALSE);
	    }
	}
	else { /* no match, rewind everything */
	    goto conf_rewind;
	}
    }
    else { /* no flags, so start search at the begining */
conf_rewind:
	fseek (_config_FILE, 0L, 0);
	if (_cont_FILE != (FILE *) 0)
	    fseek (_cont_FILE, 0L, 0);
	_config_last_offset = 0L;
	_curr_FILE = _config_FILE;
    }

    called_config_seek = TRUE;

    while (fgets(buf, sizeof(buf), _curr_FILE)) {
	/* toss leading whitespace */
	bufp = buf + strspn(buf, " \t");

	if (bufp[0] != '[')	/* only interested in section headers */
	    continue;

	/* Look for right package */
	tok = strtok (&bufp[1], CONF_TOKEND);

	/* check for e.g. "[--> c:/pctcp.ini]" */
	if (STRSAME(tok, "-->") || STRSAME(tok, "continuation-file")) {

	    if (_curr_FILE == _cont_FILE)
		continue;	/* sorry, only one continuation file */
	    
	    tok = strtok (NULL, CONF_TOKEND);

	    if (access (tok, 04) == -1) {	/* can we read it? */
		/* If we can't find a continuation file, ignore it */
DEBUG (		printf ("Couldn't find continuation-file %s, ignoring it\n", tok);)
		continue;
	    }

	    if (((cfh = sopen(tok, (O_RDONLY | O_TEXT), SH_DENYWR, 0)) == -1) ||
		((_cont_FILE = fdopen(cfh, "rt")) == (FILE *) 0)) {
		config_errno = CE_FILE;
		return FALSE;
	    } 
	    else {  /* We opened the file */
		_curr_FILE = _cont_FILE;
		_config_last_offset = -1L;
		continue;
	    }
	}

	if (*package && !STRSAME (tok, package))
	    continue;

	ptok = tok;
	tok = strtok (NULL, CONF_TOKEND);

	if (*section && !STRSAME (tok, section))
	    continue;

	stok = tok;
	tok = strtok (NULL, CONF_TOKEND);

	/* blow out if we wanted no subsection and we got one */
	if (!subsection && tok)
	    continue;

        /* blow out if the subsection doesn't match */
	if (subsection && *subsection && !STRSAME (tok, subsection))
	    continue;

	sstok = tok;

	/*
	 * at this point we've found the right place, so fill in the
	 * wildcards.
	 */

	if (!*package && package != CONF_ANY)
	    strncpy (package, ptok, MAX_SECTION_LEN);

	if (!*section && section != CONF_ANY)
	    strncpy (section, stok, MAX_SECTION_LEN);

	if (subsection && !*subsection && subsection != CONF_ANY) {
	    if (sstok)
	        strncpy (subsection, sstok, MAX_SECTION_LEN);
	    else
		subsection[0] = '\0';
	}

	_config_last_offset = ftell (_curr_FILE);
	
	/* Remember what we seek for this time. */
	strncpy (_last_package, package, MAX_SECTION_LEN);
	strncpy (_last_section, section, MAX_SECTION_LEN);
	if (subsection)
	    strncpy (_last_subsection, subsection, MAX_SECTION_LEN);
	else	
	    _last_subsection[0] = '\0';
	
	return TRUE;
    }
    
    _config_last_offset = -1L;
    strncpy (_last_package, package, MAX_SECTION_LEN);
    strncpy (_last_section, section, MAX_SECTION_LEN);
    if (subsection)
	strncpy (_last_subsection, subsection, MAX_SECTION_LEN);
    else	
	_last_subsection[0] = '\0';

    config_errno = CE_SECTION;

    return (FALSE);
}  /* end of conf_seek () */


int
config_read (char *name, int instance, char *value, int len, int flags)
{
    char *tok;
    int idx, nth_time=0, ret;
    char buf[200], *bufp;
    static char lastname[MAX_LABEL_LEN+1] = "";
    static long last_offset = -1L;

    /* Return an error if config_seek() wasn't called yet */
    if (called_config_seek == FALSE) {
	config_errno = CE_SEEK_NOT_CALLED;
	return (FALSE);
    }

    if (!name) {
	config_errno = CE_PARM_ERROR;
	return (FALSE);
    }

    config_errno = CE_OK;

    if (strlen (name) > 0)
	CONVERT_DASHES(name)	    /* Convert _ to - */

    if (flags != (int)SKIP_OLD_INIT) {
	if (use_old_init == -1)
	    use_old_init = check_use_old_init();
    
	if (use_old_init) {
	    ret = cust_read (name, instance, value, len, flags);
	    if ((ret == FALSE) || (ret == TRUE))
		return (ret);
	    /* else fall through */
	}
    }

    if (*lastname && last_offset != ftell (_curr_FILE))
	*lastname = '\0';	/* not same spot, lastname invalid */

    /* Go back to the begining of the section, if a new variable or 
     *  instance is set 
     */
    if ((lastname[0] && !STRSAME (name, "") && !STRSAME (lastname, name)) ||
	(instance != CONF_ANY_INSTANCE)) {
	fseek (_curr_FILE, _config_last_offset, 0);
	last_offset = _config_last_offset;
    }

    while (fgets(buf, sizeof(buf), _curr_FILE)) {
	/* toss leading whitespace */
	bufp = buf + strspn(buf, " \t");

	/* toss comments */
	if (*bufp == ';')
	    continue;

	/* stop at the next section head */
	if (*bufp == '[') {
	    config_errno = CE_ENTRY;
	    goto config_read_error;
        }

	/* look for the right entry */
	
	if (*bufp == '=' && *lastname && (!*name || STRSAME (lastname, name))) {
	    /*
	     * if we're looking at a line like
	     *     foo=bar
	     *        =baz	<-- this one
	     *        =rag	<-- or this one
	     * the name matches 'foo', and we're looking for the next instance,
	     * we should gobble 'em up. we've already skipped whitespace.
	     */
	    tok = bufp + 1;	/* skip the '=' */
	} else {
	    /* we're looking at a line which does have a name for its value.
	     * Split string at the first '='.
	     */
	    if ((tok = strchr(bufp, '=')) != NULL)
		*tok++ = '\0';	/* Nuke the '=' */

	    /* does the first part contain an identifier? */
	    if (strtok(bufp, CONF_TOKEND) == NULL)
		continue;
	
	    if (strlen(bufp) > 0)
		CONVERT_DASHES(bufp)	    /* Convert _ to - */

	    strncpy (lastname, bufp, MAX_LABEL_LEN);
	    lastname[MAX_LABEL_LEN] = 0;

	    /* do we want a particular name? */
	    if (*name && !STRSAME(bufp, name))
		continue;
	}

	/* is it the right instance? */
	if (instance != CONF_ANY_INSTANCE && instance != nth_time++)
	    continue;

        /* copy name to empty non-wildcard arg */
	if (!*name && name != CONF_ANY_NAME) {
	    strncpy (name, lastname, MAX_LABEL_LEN);
	    name[MAX_LABEL_LEN-1] = '\0';
	}

	/* Found right entry, return the rest of the line */
	if (tok) {
	    if (!(flags & CONF_LEADING_WHITESPACE))
		tok += strspn(tok, " \t");	/* skip whitespace */

	    /* Nuke the newline left on the end */
	    if (tok[idx = strlen(tok) - 1] == '\n')
		tok[idx] = '\0';

	    if (!(flags & CONF_TRAILING_WHITESPACE)) {
		char	*ptr;
		
		/* Start at the end of the string & remove trailing spaces */
		ptr = tok + (strlen(tok)-1);
		while ((ptr > tok) && (isspace (*ptr)))
		    *ptr-- = '\0';
	    }

	    if (value) {
		strncpy(value, tok, len);
		if (len < idx)
		    config_errno = CE_OVERFLOW;
	    }
	} else
	    *value = '\0';

	last_offset = ftell (_curr_FILE);
	return TRUE;
    }

config_read_error:
    if (last_offset >= 0L)
	fseek (_curr_FILE, last_offset, 0);	/* Go back to where we were */
    config_errno = CE_ENTRY;

    return FALSE;
}  /* end of conf_read () */


/*
 * $Log:   K:/22vcs/srclib/config/conf.c_v  $
 * 
 *    Rev 1.17   09 Nov 1992 14:40:18   seven
 *   Check if current file is the continuation file before trying to open
 * a new continuation file.
 * 
 *    Rev 1.16   06 Nov 1992 17:08:04   seven
 *   Check if the INI file is open before running config_seek() Check if
 * config_seek() was called before running config_read().
 * 
 *   Replaced two bits of duplicate code with gotos to a third.
 * 
 * 
 *    Rev 1.15   14 Sep 1992 16:07:22   paul
 *  * 21-Jul-92	rcq	changed to <rwconf.h> to <pctcp/rwconf.h>
 * 
 *    Rev 1.14   24 Jun 1992 15:38:56   paul
 * track changes from 2.1
 * 
 *    Rev 1.13   17 Jun 1992 15:01:10   paul
 * in config_seek: cast SKIP_OLD_INIT to int
 * 
 *    Rev 1.12   14 May 1992 17:38:52   paul
 *  
 * 
 *    Rev 1.11   13 May 1992 11:53:00   paul
 * added mode argument to sopen call to satisfy TurboC
 * updated copyright notice
 * 
 *    Rev 1.10   30 Mar 1992 15:56:24   arnoff
 * Remove trailing white space (unless wanted).  More work on config_open().   
 * 	---Ben
 * 
 *    Rev 1.9   30 Mar 1992 11:34:42   arnoff
 * Fixed bug introduced in config_open().   ---Ben
 * 
 *    Rev 1.8   27 Mar 1992 19:51:06   arnoff
 * Fix up continuation file handling.  Changed config_open() to open
 * file, if different.   ---Ben
 * 
 *    Rev 1.7   26 Mar 1992 21:20:42   arnoff
 * Save _last_section if config_seek failed.   ---Ben
 *
 *    Rev 1.6   23 Mar 1992 17:16:28   arnoff
 * Renamed warning_done to config_warning_done, and changed it from a
 * static to a global.   ---Ben
 * 
 *    Rev 1.5   09 Mar 1992 22:13:24   arnoff
 * Ben	Convert '_' to '-' for internal use in config_read.
 * 
 *    Rev 1.4   27 Feb 1992 17:17:32   arnoff
 * Ben	rewind in config_read, if instance is set.
 * 
 *    Rev 1.3   25 Feb 1992 20:55:16   arnoff
 * Don't rewind if config_read is looking for "".
 * 
 *    Rev 1.2   20 Feb 1992 16:37:26   arnoff
 * Cache previous seeks and seek back to beginning of section if
 * new read.   ben
 * 
 *    Rev 1.1   30 Jan 1992 00:05:40   arnoff
 *  
 */
