/* 
 * $Header:   J:/22vcs/srclib/rpc4/x_mem.c_v   1.0   10 Nov 1992 22:57:22   rcq  $
 */
#define FTP /*Copyright 1992, FTP Software, Inc.  All Rights Reserved.*/
#ifdef FTP /* added code */
/*
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 * 
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 *
 * (Edit history is maintained in RCS archives.)
 */
#else /* FTP superceded code */
/* @(#)xdr_mem.c	2.1 88/07/29 4.0 RPCSRC */
/*
 * Sun RPC is a product of Sun Microsystems, Inc. and is provided for
 * unrestricted use provided that this legend is included on all tape
 * media and as a part of the software program in whole or part.  Users
 * may copy or modify Sun RPC without charge, but are not authorized
 * to license or distribute it to anyone else except as part of a product or
 * program developed by the user.
 * 
 * SUN RPC IS PROVIDED AS IS WITH NO WARRANTIES OF ANY KIND INCLUDING THE
 * WARRANTIES OF DESIGN, MERCHANTIBILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, OR ARISING FROM A COURSE OF DEALING, USAGE OR TRADE PRACTICE.
 * 
 * Sun RPC is provided with no support and without any obligation on the
 * part of Sun Microsystems, Inc. to assist in its use, correction,
 * modification or enhancement.
 * 
 * SUN MICROSYSTEMS, INC. SHALL HAVE NO LIABILITY WITH RESPECT TO THE
 * INFRINGEMENT OF COPYRIGHTS, TRADE SECRETS OR ANY PATENTS BY SUN RPC
 * OR ANY PART THEREOF.
 * 
 * In no event will Sun Microsystems, Inc. be liable for any lost revenue
 * or profits or other special, indirect and consequential damages, even if
 * Sun has been advised of the possibility of such damages.
 * 
 * Sun Microsystems, Inc.
 * 2550 Garcia Avenue
 * Mountain View, California  94043
 */
#if !defined(lint) && defined(SCCSIDS)
static char sccsid[] = "@(#)xdr_mem.c 1.19 87/08/11 Copyr 1984 Sun Micro";
#endif

/*
 * xdr_mem.h, XDR implementation using memory buffers.
 *
 * Copyright (C) 1984, Sun Microsystems, Inc.
 *
 * If you have some data to be interpreted as external data representation
 * or to be converted to external data representation in a memory buffer,
 * then this is the package for you.
 *
 */
#endif /* FTP */

#ifdef MSDOS
#define _DLL_FLAGS
#endif

#ifdef FTP /* added code */
#include <rpc/types.h>
#include <rpc/xdr.h>
#include <pctcp/types.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <4bsddefs.h>
#include <sys/types.h>
#ifndef MSDOS
#include <bsd.h>
#endif
#else /* FTP superceded code */
#include <rpc/types.h>
#include <rpc/xdr.h>
#include <netinet/in.h>
#endif /* FTP */

#ifdef FTP /* added code */
static bool_t _DLL_FLAGS xdrmem_getlong(XDR *xdrs, long *lp);
static bool_t _DLL_FLAGS xdrmem_putlong(XDR *xdrs, long *lp);
static bool_t _DLL_FLAGS xdrmem_getbytes(XDR *xdrs, caddr_t addr, u_int len);
static bool_t _DLL_FLAGS xdrmem_putbytes(XDR *xdrs, caddr_t addr, u_int len);
static u_int _DLL_FLAGS xdrmem_getpos(XDR *xdrs);
static bool_t _DLL_FLAGS xdrmem_setpos(XDR *xdrs, u_int pos);
static long *_DLL_FLAGS xdrmem_inline(XDR *xdrs, int len);
static void _DLL_FLAGS xdrmem_destroy(void);
#else /* FTP superceded code */
static bool_t	xdrmem_getlong();
static bool_t	xdrmem_putlong();
static bool_t	xdrmem_getbytes();
static bool_t	xdrmem_putbytes();
static u_int	xdrmem_getpos();
static bool_t	xdrmem_setpos();
static long *	xdrmem_inline();
static void	xdrmem_destroy();
#endif /* FTP */

static struct	xdr_ops xdrmem_ops = {
	xdrmem_getlong,
	xdrmem_putlong,
	xdrmem_getbytes,
	xdrmem_putbytes,
	xdrmem_getpos,
	xdrmem_setpos,
	xdrmem_inline,
	xdrmem_destroy
};

/*
 * The procedure xdrmem_create initializes a stream descriptor for a
 * memory buffer.  
 */
#ifdef FTP /* added code */
void
_DLL_FLAGS
xdrmem_create(
	register XDR *xdrs,
	caddr_t addr,
	u_int size,
	enum xdr_op op
)
#else /* FTP superceded code */
void
xdrmem_create(xdrs, addr, size, op)
	register XDR *xdrs;
	caddr_t addr;
	u_int size;
	enum xdr_op op;
#endif /* FTP */
{

	xdrs->x_op = op;
	xdrs->x_ops = &xdrmem_ops;
	xdrs->x_private = xdrs->x_base = addr;
	xdrs->x_handy = size;
}

#ifdef FTP /* added code */
static void
_DLL_FLAGS
xdrmem_destroy(
	/*XDR *xdrs;*/
)
#else /* FTP superceded code */
static void
xdrmem_destroy(/*xdrs*/)
	/*XDR *xdrs;*/
#endif /* FTP */
{
}

#ifdef FTP /* added code */
static bool_t
_DLL_FLAGS
xdrmem_getlong(
	register XDR *xdrs,
	long *lp
)
#else /* FTP superceded code */
static bool_t
xdrmem_getlong(xdrs, lp)
	register XDR *xdrs;
	long *lp;
#endif /* FTP */
{

	if ((xdrs->x_handy -= sizeof(long)) < 0)
		return (FALSE);
	*lp = (long)ntohl((u_long)(*((long *)(xdrs->x_private))));
	xdrs->x_private += sizeof(long);
	return (TRUE);
}

#ifdef FTP /* added code */
static bool_t
_DLL_FLAGS
xdrmem_putlong(
	register XDR *xdrs,
	long *lp
)
#else /* FTP superceded code */
static bool_t
xdrmem_putlong(xdrs, lp)
	register XDR *xdrs;
	long *lp;
	
	
#endif /* FTP */
{
        long temp;
	if ((xdrs->x_handy -= sizeof(long)) < 0)
		return (FALSE);
        temp = (long)htonl((u_long)(*lp));
        *(long *)xdrs->x_private = temp;
	xdrs->x_private += sizeof(long);
	return (TRUE);
}

#ifdef FTP /* added code */
static bool_t
_DLL_FLAGS
xdrmem_getbytes(
	register XDR *xdrs,
	caddr_t addr,
	register u_int len
)
#else /* FTP superceded code */
static bool_t
xdrmem_getbytes(xdrs, addr, len)
	register XDR *xdrs;
	caddr_t addr;
	register u_int len;
#endif /* FTP */
{

	if ((xdrs->x_handy -= len) < 0)
		return (FALSE);
	bcopy(xdrs->x_private, addr, len);
	xdrs->x_private += len;
	return (TRUE);
}

#ifdef FTP /* added code */
static bool_t
_DLL_FLAGS
xdrmem_putbytes(
	register XDR *xdrs,
	caddr_t addr,
	register u_int len
)
#else /* FTP superceded code */
static bool_t
xdrmem_putbytes(xdrs, addr, len)
	register XDR *xdrs;
	caddr_t addr;
	register u_int len;
#endif /* FTP */
{

	if ((xdrs->x_handy -= len) < 0)
		return (FALSE);
	bcopy(addr, xdrs->x_private, len);
	xdrs->x_private += len;
	return (TRUE);
}

#ifdef FTP /* added code */
static u_int
_DLL_FLAGS
xdrmem_getpos(
	register XDR *xdrs
)
#else /* FTP superceded code */
static u_int
xdrmem_getpos(xdrs)
	register XDR *xdrs;
#endif /* FTP */
{

#ifdef FTP /* added code */
	return (xdrs->x_private - xdrs->x_base);
#else /* FTP superceded code */
	return ((u_int)xdrs->x_private - (u_int)xdrs->x_base);
#endif /* FTP */
}

#ifdef FTP /* added code */
static bool_t
_DLL_FLAGS
xdrmem_setpos(
	register XDR *xdrs,
	u_int pos
)
#else /* FTP superceded code */
static bool_t
xdrmem_setpos(xdrs, pos)
	register XDR *xdrs;
	u_int pos;
#endif /* FTP */
{
	register caddr_t newaddr = xdrs->x_base + pos;
	register caddr_t lastaddr = xdrs->x_private + xdrs->x_handy;

	if ((long)newaddr > (long)lastaddr)
		return (FALSE);
	xdrs->x_private = newaddr;
#ifdef FTP /* added code */
	xdrs->x_handy = lastaddr - newaddr;
#else /* FTP superceded code */
	xdrs->x_handy = (int)lastaddr - (int)newaddr;
#endif /* FTP */
	return (TRUE);
}

#ifdef FTP /* added code */
static long *
_DLL_FLAGS
xdrmem_inline(
	register XDR *xdrs,
	int len
)
#else /* FTP superceded code */
static long *
xdrmem_inline(xdrs, len)
	register XDR *xdrs;
	int len;
#endif /* FTP */
{
	long *buf = 0;

	if (xdrs->x_handy >= len) {
		xdrs->x_handy -= len;
		buf = (long *) xdrs->x_private;
		xdrs->x_private += len;
	}
	return (buf);
}
/* 
 * $Log:   J:/22vcs/srclib/rpc4/x_mem.c_v  $
 * 
 *    Rev 1.0   10 Nov 1992 22:57:22   rcq
 * Initial revision.
 */