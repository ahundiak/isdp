/*
 * $Header:   J:/22vcs/srclib/socket/gettimeo.c_v   1.4   02 Oct 1992 18:54:40   rcq  $
 */

/*
 * GETTIMEO.C - Get time of day
 *
 * Copyright (C) 1987-1992 by FTP Software, Inc.  All rights reserved.
 *
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 *
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 *
 * Edit history:
 * 25-May-90    vicka    created
 * 07-Nov-91	paul	changed to new-style function declarators,
 *			added function return types,
 *			changed forever loops from while(1) to for(;;)
 * 27-Nov-91    rcq      added check for TZ env variable, call to tzset()
 *                        and use of IPCUST timezone setting.
 * 14-Aug-92    rcq     updated the copyright in comments
 */

#include <stdio.h>
#include <stdlib.h>

#include <errno.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/timeb.h>
#include <debug.h>

#include <pctcp/types.h>
#include <pctcp/ipconfig.h>
#include "4bsd.h"

int gettimeofday(struct timeval  *tp, struct timezone *tzp)
{
    struct timeb  foo;
    int tz_flag;
    struct ipconfig ipconf;

#ifdef	DEBUG
	printf("gettimeofday(tp = x%Np, tzp = x%Np)", tp, tzp);
#endif

    /* Check for MSC TimeZone environment variable */
    tz_flag = ((getenv("TZ") == 0) ? 0 : 1);

    if (tz_flag)
        tzset();  /* To setup internal global variables */

    ftime(&foo);  /* get time and tz settings (if any) */

    if(tp) {
	tp->tv_sec = foo.time;
	tp->tv_usec = (long) foo.millitm * 1000L;
    } else
	bomb(EFAULT);

    if(tzp) {
        if (tz_flag)  {                         /* If TZ env var set, */
                tzp->tz_minuteswest = foo.timezone; /*  use MSC TZ setting */
                tzp->tz_dsttime = foo.dstflag;
        } else {                              /* Else use IPCUST TZ offset */
		if ((get_ipconfig(INMEMORY_IPCONFIG, &ipconf)) == 0) {
                     tzp->tz_minuteswest = 0;   /* BOGUS Values! */
                     tzp->tz_dsttime = 0;
                } else {
                     tzp->tz_minuteswest = ipconf.c_tmoffset;
                     /* If second char in TZ Label 'D', daylight savings! */
                     tzp->tz_dsttime =
                       (toupper(ipconf.c_tmlabel[1]) == 'D') ? 1 : 0;
	        }
        } 
   } /* end if (tzp) */
   
	dreturn(" = %d\n", 0);
	
} /* end gettimeofday() */


/*
 * $Log:   J:/22vcs/srclib/socket/gettimeo.c_v  $
 * 
 *    Rev 1.4   02 Oct 1992 18:54:40   rcq
 * merged changes done in 2.1
 * 
 *    Rev 1.3   27 Aug 1992 16:03:20   arnoff
 *  * 27-Nov-91    rcq      added check for TZ env variable, call to tzset()
 *  *                        and use of IPCUST timezone setting.
 *  * 14-Aug-92    rcq     updated the copyright in comments
 * 
 *    Rev 1.2   13 Apr 1992 16:04:06   arnoff
 * Added pctcp header files
 * 
 *    Rev 1.1   30 Jan 1992 00:51:22   arnoff
 *  
 */
