/*
 * $Header:   K:/21vcs/srccmd/samples.win/pplaint.c_v   1.3   06 May 1992 16:03:10   arnoff  $
 */

/*
 * Copyright (C) 1991-1992 by FTP Software, Inc.
 * 
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 * 
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 *
 * 
 * EDIT HISTORY:
 * 05-Sep-90  msd@ayuda	Original author.
 * 04-Oct-90  msd@ayuda	First pre-release.
 * 01-Apr-91  msd@ayuda	To FTP for 2.05 pl 2 beta.
 * 06-May-92  ftp	DevKit 2.1 beta.
 */

/* "pplaint.c" -- A common complaint generator used in the simple
    test applications for PC/TCP under Windows 3.x. */

#include <stdio.h>
#include <windows.h>
#include <pctcp/winapp.h>
#include "fmters.h"
#include "plaints.h"


/* I/O error code complaint dialog, including the given string.  'liveOn'
   flag tells whether to return or die. */
int
perrorTypePlaint (iotypeP, liveOn)
char FAR *iotypeP;
int liveOn;
{
	char prbuf[140];

	if (inError)
		return 0;	/* don't reenter */
	wsprintf(prbuf, "%s error: %s%s", iotypeP
	  , (LPSTR) pr_errno(), (LPSTR) pr_suberrno());
	return otherPlaint(prbuf, liveOn);
}


/* eof */

/*
 * $Log:   K:/21vcs/srccmd/samples.win/pplaint.c_v  $
 * 
 *    Rev 1.3   06 May 1992 16:03:10   arnoff
 *  * 06-May-92  ftp	DevKit 2.1 beta.
 * 
 *    Rev 1.2   03 Feb 1992 22:01:12   arnoff
 * pre beta-2 testing freeze
 * 
 *    Rev 1.1   29 Jan 1992 22:47:06   arnoff
 *  
 */
