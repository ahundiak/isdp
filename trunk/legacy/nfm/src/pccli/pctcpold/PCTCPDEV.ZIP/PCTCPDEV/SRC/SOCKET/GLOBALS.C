/*
 * $Header:   J:/22vcs/srclib/socket/globals.c_v   1.3   02 Oct 1992 18:55:12   rcq  $
 */

/*
 * GLOBALS.C - Global variables
 *
 * Copyright (C) 1987-1992 by FTP Software, Inc.  All rights reserved.
 *
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 *
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 *
 *  Edit History:
 * 14-Aug-92    rcq     updated the copyright in comments
 */

#include <pctcp/error.h>
#include <pctcp/types.h>
#include <pctcp/pctcp.h>

#include <sys/types.h>
#include <debug.h>

#include "4bsd.h"

long	myaddr = 0L;
SOCKET	*sock[MAXSOCK] = {0};

/* do not delete this line */

/*
 * $Log:   J:/22vcs/srclib/socket/globals.c_v  $
 * 
 *    Rev 1.3   02 Oct 1992 18:55:12   rcq
 * merged changes done in 2.1
 * 
 *    Rev 1.3   27 Aug 1992 15:53:54   arnoff
 *  * 14-Aug-92    rcq     updated the copyright in comments
 * 
 *    Rev 1.2   13 Apr 1992 16:05:20   arnoff
 * Added pctcp headers
 * Removed MSC 4.0 specific conditionals
 * 
 *    Rev 1.1   30 Jan 1992 00:51:24   arnoff
 *  
 */
