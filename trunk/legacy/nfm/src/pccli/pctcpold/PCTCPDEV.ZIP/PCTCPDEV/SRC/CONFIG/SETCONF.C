/*
 * $Header:   K:/22vcs/srclib/config/setconf.c_v   1.18   18 Nov 1992 16:00:20   seven  $
 */

/* setconf.c	change entries in the config file.
 */

/* Copyright (C) 1991 by FTP Software, Inc.  All rights reserved.
 * 
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 * 
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 * 
 * Edit History
 * 22-Jun-91	rehmi	put this in the source tree.
 * 23-jun-91	wls	added subsection support
 * 24-jun-91	wls	handle changes to very last section of file
 * 24-jun-91	wls	setconf now allows multiple instances of a given item
 * 05-Jul-91	Ben	Copied macro STRSAME() from conf.c to here.
 * 14-Jul-91	rehmi	re-incorporated wls' changes. where'd they go?
 * 15-Jul-91	Ben	write subsect to subsect, not sect.  fputs '\n'.
 * 16-Jul-91	Ben	Try .\pctcp.ini as a last resort.  Reduced number of
 *			 NULLs of wrong type.  If a entry has been found,
 *			 Don't use it twice.  Skip if old duplicate line.
 *			 Insert new item at end of list.
 * 17-Jul-91	Ben	Removed exit from OUT_OF_MEMORY macro.  Make setconf()
 *			 return (FALSE) if it had a problem.  Make mk_fname
 *			 return (NULL) if it had a problem.
 * 20-Jul-91	rehmi	handle creation of a new config file correctly.
 * 22-Jul-91	rehmi	handle NULL subsection correctly in setconf().
 * 31-Jul-91	rehmi	tabs now whitespace, add new lines to last section.
 * 05-Nov-91	paul	added function return types
 * 02-Jan-92	Ben	Try to remove white space from variable name
 *			 in setconf().
 * 16-Jan-92	paul	made change_list, mk_fnames static,
 *			compressed the DEBUG definition
 * 16-Jan-92	Ben	Changed fopens to sopen/fdopen
 * 23-Jan-92	Ben	Check why rename failed, and return an error.
 * 20-Feb-92	Ben	Find a safe name for the backup file (e.g. FOO.001).
 * 21-Feb-92	Ben	Use correct size for malloc.
 * 25-Feb-92	Ben	Don't read the old ini file if it doesn't exist.
 * 26-Feb-92	Ben	Fine tune creating temp filename ('OO.INI).
 * 27-Feb-92	Ben	Skip over / or \ before adding '`'.
 * 06-Mar-92	rehmi	freed up section, subsect, name, and value fields in
 *			change_list per wls' pointer to bogosity.
 * 06-mar-92	wls	also free bak_cfname and new_cfname
 *			added configure_setconf();
 * 06-Mar-92	Ben	Moved a '}' out of an IFDEF.  Moved wls' to test into
 *			 the do {} while loop.
 * 09-Mar-92	Ben	Added a newline before new sections.  And removed an
 *			 extraneous newline when adding an new entry.
 * 12-Mar-92	Ben	Remove extraneous \r & \n from value in setconf().
 * 23-Mar-92	Ben	Changed "foo=bar" to "foo = bar".
 * 14-May-92	Ben	Merged setconf_end() and configure_setconf() and 
 *			 renamed the result config_flush().  Changed
 *			 setconf_flags to backup_flags and made it a local 
 *			 variable.
 * 14-May-92	Ben	Converted setconf() to config_write().  Added flags
 *			 and package for writes.  Match both '-' & '_' when
 *			 comparing variable names.
 * 25-Jun-92	plummer	Don't output a space before a null section or subsect
 * 26-Jun-92	plummer	Include package when looking for changed sections
 * 21-Jul-92	rcq	changed to <rwconf.h> to <pctcp/rwconf.h>
 * 09-Nov-92	Ben	Carried over Paul's change from conf.h
 *  13-May-92	 paul	 added mode argument to sopen call to satisfy TurboC
 * 09-Nov-92	Ben	Accept either "-->" or "continuation-file".  Copy
 *			 remainder of old ini file before switching to
 *			 continuation file.
 * 10-Nov-92	Ben	Fixed writing to config file.
 * 16-Nov-92	Ben	Fixed another bug in writing to continuation files.
 * 18-Nov-92	Ben	Ignore leading white space when comparing variables
 *			 to change.  Check file permission before writing
 *			 to INI file.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <share.h>	/* for sopen's settings */
#include <errno.h>	/* for ENOENT		*/
#include <fcntl.h>
#include <io.h>


#include <pctcp/rwconf.h>

#define FALSE 0
#define TRUE !FALSE
#define STRSAME(a,b)		(stricmp(a,b)==0)

#if defined(DEBUG) && !defined(WINDOWS)
#undef DEBUG
#define DEBUG(x) x
#else
#undef DEBUG
#define DEBUG(x)
#endif

typedef struct _section_changes {
	char	*name;
	char	*value;
	int	flags;
	char	found;
	struct _section_changes *next;
} section_changes;

#define NULL_ITEM	((section_changes *) 0)

typedef struct _changes {
	char	*package;
	char	*section;
	char	*subsect;
	char	found;
	struct _changes *next;
	section_changes *items;
} changes;

#define NULL_CHANGES	((changes *) 0)

static changes *change_list = NULL_CHANGES;

static char backup_fname[15] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

#ifndef WINDOWS
#define OUT_OF_MEMORY() 	puts("out of memory!"); 
#else
#define OUT_OF_MEMORY()
#endif

#define	NO_MATCH	0
#define	OLD_MATCH	1
#define	NEW_MATCH	3

static char *
strsave (char *s)
{
	char *p = malloc (strlen(s) + 1);

	if (p == NULL) {
		OUT_OF_MEMORY();
		return (NULL);
	}

	strcpy (p, s);
	return p;
}

/******************************************************************
 * config_write() - adds a variable change to the change list
 ******************************************************************/

int config_write (char *package, char *section, char *subsect, char *name, 
	     char *value, int flags)
{
	char			*ptr;
	changes 		*p;
	section_changes 	*q;
	section_changes 	*last_q, *tmp_q;
	
	for (p = change_list; p; p = p->next)
	    if (STRSAME (p->section, section) &&
		(subsect == NULL ? p->subsect == NULL : STRSAME (p->subsect, subsect)))
		break;

	if (package == NULL)
	    package = _config_pctcp_package;

	/* if we didn't find one, make one...
	 */
	if (p == NULL) {
	    p = (changes *) malloc (sizeof (changes));
	    if (p == NULL) {
		OUT_OF_MEMORY();
		return (FALSE);
	    }

	    if (section == NULL)
		return (FALSE);

	    if ((p->package = strsave (package)) == NULL)
		return FALSE;

	    if ((p->section = strsave (section)) == NULL)
		return FALSE;

	    if (subsect == NULL)
		p->subsect = NULL;
	    else if ((p->subsect = strsave (subsect)) == NULL)
	        return FALSE;
	
	    p->found = 0;
	    p->items = NULL_ITEM;
	    p->next = change_list;
	    change_list = p;
	}
	
	/* remove white space from NAME */
	strtok (name, " \t");

#ifdef never
	/* This code would insure that there is only one instance of a
	 * given varable.   Right now, this isn't what we want -wls */

	/* look for the item in the item list for this section */
	for (q = p->items; q; q = q->next)
		if (STRSAME (q->name, name))
			break;

	/* if we didn't find one, make one... */
	if (!q) {
#endif

	/* create a new section changes struct for this item
	 */
	q = (section_changes *) malloc(sizeof(section_changes));
	if (q == NULL_ITEM) {
		OUT_OF_MEMORY();
		return (FALSE);
	}

	q->found = 0;
	q->flags = flags;
	if ((q->name = strsave (name)) == NULL)
	    return FALSE;

	/* Remove \r & \n from the end of value */
	ptr = strrchr (value, '\r');
	if (ptr != NULL)
	    *ptr = '\0';
	else
	{
	    ptr = strrchr (value, '\n');
	    if (ptr != NULL)
		*ptr = '\0';
	}

	if ((q->value = strsave (value)) == NULL)
	    return FALSE;
		
	/* insert q at end of items list */
	if (p->items == NULL_ITEM)
		p->items = q;
	else {
		for (tmp_q = p->items; tmp_q !=NULL_ITEM; tmp_q =tmp_q->next)
		    last_q = tmp_q;

		last_q->next = q;
	}

	q->next = NULL_ITEM;

#ifdef never
	}
#endif    

	return TRUE;
}  /* end of config_write() */


/******************************************************************
 * mk_fnames() - given a config file name, decide what to call the
 * 		 backup file and the temp file.
 ******************************************************************/
		    
static int mk_fnames (char *cfname, char **bak_cfnamep, char **new_cfnamep, 
			int backup_flags)
{
    char *tok, *p, *ptr;
    int	i, len, try;

    /* Find last element of config file name and replace its first char
     * with '`' to make a new filename. i hate DOS.
     */
    if ((*new_cfnamep = strsave (cfname)) == NULL)
	return (FALSE);

    ptr = *new_cfnamep;
    if (*(ptr+1) == ':')	    /* Skip over the drive name */
	ptr = (*new_cfnamep)+2;
    
    tok = strrchr (ptr, '\\');
    if (!tok)
	tok = ptr;

    p = strrchr (tok, '/');
    if (!p)
	p = tok;
	
    /* skip over / or \ */
    if ((*p == '\\') || (*p == '/'))
	++p;

    /* Change the first character to a '`' */  
    *p = '`';

    /*------------------------------------------------------------------------
     * Now we create a backup filename based on backup_fname and backup_flags
     *------------------------------------------------------------------------
     * if the user told us not to create a backup, set bak_cfname to NULL
     */
    if (backup_flags & CF_FLAG_NOBACKUP) {
	*bak_cfnamep = (char *) 0;
	return(TRUE);
    }
    
    /* if we have a name in backup_fname that does *NOT* begin with a
     * '.', then we just use it.
     */
    if ((backup_fname[0] != 0) && (backup_fname[0] != '.')) {
	if ((*bak_cfnamep = strsave (backup_fname)) == NULL)
	    return (FALSE);
	else return(TRUE);
    }
    
    /* well, now we know we have to build one based on cfname, but
     * with a different extension, so initialize a few things...
     */
    
    len = strlen (cfname) - 1;
    
    if ((*bak_cfnamep = malloc (strlen (cfname)+5)) == NULL) {
	OUT_OF_MEMORY();
	return (FALSE);
    }
    else {
	strcpy (*bak_cfnamep, cfname);
    }
    
    tok = *bak_cfnamep;

    /* Find the end of the name (begining of extension) 
     */
    for (i = len; i > (len - 4); i--)
    {
	if ((tok[i] == '\\') || (tok[i] == '/') || 
	    (tok[i] == ':') || (tok[i] == '.'))
	{
	    if (tok[i] == '.') {
		tok[i] = '\0';
	    }
	    break;
	}
    }
    
    len = strlen (tok);  /* get the length of the name without extension */
    
    
    /* if the value in backup_fname begins with a ".", then we use it
     * as an extension for the existing cfname...
     */
    if (backup_fname[0] == '.') {
	backup_fname[4] = 0;	        /* make sure it's not too long...*/
	strcpy(tok+len, backup_fname);
	return(TRUE);
    }

    /* Now use Ben's default algorythm to Find a safe name for the backup 
     * file.  Try extensions from 001, on up... (e.g.FOO.001, FOO,002, etc.) 
     */
    try = 1;

    do {
	sprintf (tok+len, ".%03d", try++);

#ifndef WINDOWS	
	/* if we had to try 200 different file names, it's time to 
	 * start pestering the user to clean up the mess...
	 */
	if (try == 200) {
	    printf(
		"Warning: you have over 200 backup files with the creation of %s\n",
		*bak_cfnamep);
	    }
#endif	    
	/* if we got up to 999, give up...
	 */
	if (try == 999) {
	    *bak_cfnamep = (char *) 0;
	    free(*bak_cfnamep);
	    return(FALSE);
	}

    } while (access (tok, 00) == 0);

DEBUG (printf ("backup name = %s, tempname = %s\n", *bak_cfnamep, *new_cfnamep);)

    return (TRUE);
}  /* end of mk_fnames() */


/**************************************************************************
 * config_flush() - 
 * copy the old config file to a temp file, incorporating all the
 * changes in "change_list", then save the old config file and replace
 * it with the new one.
 *
 * set a backup filename to be used by mk_fnames()
 *
 * interpretation of bakname (given a config file name of ABCD.INI)
 *
 *    if(bakname[0] == 0) ==> backups will go to ABCD.001, ABCD.002, etc.
 *    if(bakname[0] == '.') (ie, ".OLD")  backups will go to ABCD.OLD
 *    else  backups will go to the exact filename specified
 *
 * values for backup_flags are defined in rwconf.h
 *
 *************************************************************************/
		    
int config_flush (char *cfname, char *bakname, unsigned int flags)
{
    char *tok, *package, *sect, *subsect;
    char *copy_out, *var_ptr;
    char buf[256], parsebuf[256];
    char *new_cfname, *bak_cfname;
    FILE *new_cf;
    FILE *cf = NULL;
    changes *cp = NULL_CHANGES;
    section_changes *scp;
    int fh, match = NO_MATCH;
DEBUG( int line = 0; )
    
    if(bakname) {
	strcpy(backup_fname, bakname);
    } else {
	backup_fname[0] = 0;
    }


    /* get the name of the pctcp.ini file
     */
    if (cfname == NULL)
	if ((cfname = getenv("PCTCP")) == NULL)
	    if ((cfname = getenv("FTP_CONFIG")) == NULL)
		cfname = "pctcp.ini";  		/* try .\pctcp.ini */

    /* Don't write to the INI file if we don't have write access to it */
    if ((access (cfname, 02) == -1) && (errno == EACCES))
    {
DEBUG ( printf ("%s is read-only\n", cfname);)
	config_errno = CE_PERMISSION;
	return (FALSE);
    }

    if (((fh = sopen(cfname, (O_RDONLY | O_TEXT), SH_DENYWR, 0)) == -1) ||
	((cf = fdopen(fh, "rt")) == NULL)) {

	new_cfname = cfname;
	bak_cfname = NULL;
    } else {
	/* get names for the temp and backup files */
	if (mk_fnames (cfname, &bak_cfname, &new_cfname, flags) == FALSE)
	    return (FALSE);
    }

    if ((new_cf = fopen(new_cfname, "w")) == (FILE *) 0) {
	fclose (cf);
	return (FALSE);
    }

DEBUG(	printf ("config_flush is writing to file: %s\n", new_cfname);)

    cp = NULL_CHANGES;

    if (cf == NULL) 
	goto skip_old_read;
    
    /* now start copying lines from the old to the new config file.
     * if there's a line to copy, copy_out will point at it.
     */

#define FETCH_NEXT_LINE continue	/* parse this, bucko! */

    /* Leave this for expression alone, it looks weird, but it works  ---Ben*/
    for (copy_out = NULL; 
	fgets(copy_out = buf, sizeof(buf), cf);
	copy_out && fputs (copy_out, new_cf)) {

	match = NO_MATCH;		/* clear flag */

DEBUG(	printf ("%3d: %s", ++line, buf);)

	if (buf[0] == '[') {	/* start of a new section or subsection */
DEBUG(	    printf ("start of section\n");)

	    /* if changes were being made to the previous section, look
	     * through the list for variables that we didn't find at
	     * all, and append the new line to the file
	     */
	    if (cp) {
		for (scp = cp->items; scp != NULL_ITEM; scp = scp->next)
		    if (!scp->found) {
DEBUG(			printf ("copy additional changes: %s\n",scp->name);)
			fputs (scp->name, new_cf);
			fputs (" = ", new_cf);
			fputs (scp->value, new_cf);
			fputs ("\n", new_cf);
		    }

		cp = NULL_CHANGES;
	    }

	    strcpy (parsebuf, buf);

	    /* extract package name */
	    package = strtok(&parsebuf[1], CONF_TOKEND);

	    if (STRSAME(package, "-->") || STRSAME(package, "continuation-file")) {
		int ch;

		/* switch INI files */
		
		fputs (copy_out, new_cf); /* write out current line */
		copy_out = NULL;

		/* Copy the rest of file old file to new file */
		while ((ch = getc (cf)) != EOF) {
		    putc (ch, new_cf);
		}

		/* Close the original INI */
		fclose (cf);
		fclose (new_cf);

		if (bak_cfname) {
		    unlink (bak_cfname);
		    if (rename (cfname, bak_cfname) != 0) {
#ifdef WINDOWS
#else
			if (errno != ENOENT) {
DEBUG (			    printf ("Unable to rename %s to %s\n", new_cfname, cfname);)
			    config_errno = CE_PERMISSION;
			    return (FALSE);
			}
#endif
			free(bak_cfname);
		    }
		} else {    /* if we don't rename it, we have to delete it */
		    unlink(cfname);  
		}
		rename (new_cfname, cfname);
		free (new_cfname);

		/* get continuation file name */
		if ((cfname = strsave (strtok(NULL, CONF_TOKEND))) == NULL)
		    return (FALSE);
DEBUG(		printf ("got a continuance to '%s'\n", cfname);)

		/*  Don't write to the INI file if we don't have
		 * write access to it
		 */
		if ((access (cfname, 02) == -1) && (errno == EACCES))
		{
DEBUG (		    printf ("%s is read-only\n", cfname);)
		    config_errno = CE_PERMISSION;
		    return (FALSE);
		}

		if (((fh = sopen(cfname, (O_RDONLY | O_TEXT), SH_DENYWR, 0)) == -1) ||
		    ((cf = fdopen(fh, "rt")) == NULL)) {
		    new_cfname = cfname;    /* File doesn't exist, so don't */
		    bak_cfname = NULL;	    /* bother with a temp file	    */
		} else {	    
		    /* get names for the temp and backup files */
		    if (mk_fnames (cfname, &bak_cfname, &new_cfname, flags) == FALSE)
			return (FALSE);
		}

		if ((new_cf = fopen(new_cfname, "w")) == (FILE *) 0) {
		    fclose (cf);
		    return (FALSE);
		}

DEBUG(		line = 0;)

DEBUG(	printf ("config_flush is now writing to file: %s\n", new_cfname);)

		FETCH_NEXT_LINE;
	    }  /* end of if (continuation) */

DEBUG(	    printf (" [%s", package);)

	    /* get the section name */
	    sect = strtok(NULL, CONF_TOKEND);
DEBUG(	    printf (" %s", sect);)

	    /* get the subsection name */
	    subsect = strtok(NULL, CONF_TOKEND);
DEBUG(	    printf (" %s]\n", subsect ? subsect : "");)

	    /* check each of the sections in change_list to see if 
	     * we have a match for package, section and subsection... */

	    for (cp = change_list; cp != NULL_CHANGES; cp = cp->next)
		if ((STRSAME (package, cp->package))  /* pkg cannot be NULL */
		&&  (sect == NULL ?
			(cp->section == NULL || !*cp->section)
		       : STRSAME (sect, cp->section))
		&&  (subsect == NULL ?
			(cp->subsect == NULL || !*cp->subsect)
		       : STRSAME (subsect, cp->subsect)))
		{
		    cp->found = TRUE;
DEBUG(		    printf ("found a section to change!\n");)
		    break;
		}

	    FETCH_NEXT_LINE;
	}  /* end of if (start of new section) */

	if (cp == NULL_CHANGES) 
		FETCH_NEXT_LINE;	/* no changes in this section */
	
DEBUG(	printf ("oh boy! we're changing section %s!\n", cp->section);)

	/* don't bother with the line if it doesn't even have an '='
	 */
	if ((tok = strchr(buf, '=')) != NULL) { 
	    strcpy (parsebuf, buf);
	    /* See if there's a name=value on this line */
	    if (strtok(parsebuf, CONF_TOKEND) == NULL) {	/* had = */
		FETCH_NEXT_LINE;
	    }
DEBUG(	    printf ("found name %s.\n", parsebuf);)
	
	    /* for each of the changes in this section
	     */
	    for (scp = cp->items; scp != NULL_ITEM; scp = scp->next) 
	    {
DEBUG(		printf ("is it '%s'? ", scp->name);)

		/* if we get an exact match, write out the change
		 */

		/* convert '_' to '-' */
		for (var_ptr = parsebuf; *var_ptr; var_ptr++)             
		    if (*var_ptr == '_')
			*var_ptr = '-';

		/* Skip leading whitespace for comparissons */
		var_ptr = parsebuf + strspn (parsebuf, " \t");

		if (STRSAME(var_ptr, scp->name)) 
		{
		    if (scp->found == TRUE)
		    {
			match = OLD_MATCH;
DEBUG(			printf ("nope, used.\n");)
			continue;		/* eeww it's used */
		    }
DEBUG(		    printf ("yes! replacing %s with %s\n", tok, scp->value);)
		    scp->found = TRUE;
		    match = NEW_MATCH;
		    fputs (scp->name, new_cf);
		    fputs (" = ", new_cf);
		    fputs (scp->value, new_cf);
		    fputs ("\n", new_cf);
DEBUG(		    fputs (";; touched previous line\n", new_cf);)
		    copy_out = NULL;
		    break;
		} 
		else 
		{
DEBUG(		    printf ("no.\n");)
		    match = NO_MATCH;
		}
	    }  /* end of for (items) loop */

	    if (match == OLD_MATCH) 
	    {
		copy_out = NULL;	/* skip old duplicate lines */
		match = NO_MATCH;	/* reset flag */
	    }

	} /* END - if (the current line contained an '=') */
    } /* END - MAIN LOOP for(each line in the old config file) */

#undef FETCH_NEXT_LINE

skip_old_read:

    /* we'll bypass the copy loop above if there was no old
     * config file.
     */

    /* if changes were being made to the very last section, we
     * need to check for stuff that wasn't "found" because
     * we hit the end of file before we got to the next section
     * where we usually write these things out
     */
    if (cp != NULL_CHANGES) {
	for (scp = cp->items; scp != NULL_ITEM; scp = scp->next)
	    if (!scp->found) {
DEBUG(		printf ("copy left over changes: %s\n", scp->name);)
		fputs (scp->name, new_cf);
		fputs (" = ", new_cf);
		fputs (scp->value, new_cf);
		fputs ("\n", new_cf);
	    }
	cp = NULL_CHANGES;
    }

    /* now for each change for which we didn't find a section,
     * create a new section at the end of the file, and write the changes
     */
    for (cp = change_list; cp != NULL_CHANGES; cp = cp->next) {
	if (!cp->found) {
DEBUG(	    printf ("copy left over sections: %s\n",cp->section);)

	    /* print [package section subsection] */
	    fputs ("\n[", new_cf);
	    fputs (cp->package, new_cf);
	    if ( cp->section != NULL && strlen(cp->section)>0 )
	    {
		    fputs (" ", new_cf);
		    fputs (cp->section, new_cf);
	    }
	    if ( cp->subsect != NULL && strlen(cp->subsect)>0 )
	    {
		fputs (" ", new_cf);
		fputs (cp->subsect, new_cf);
	    }
	    fputs ("]\n", new_cf);
	    for (scp = cp->items; scp != NULL_ITEM; scp = scp->next) {
		fputs (scp->name, new_cf);
		fputs (" = ", new_cf);
		fputs (scp->value, new_cf);
		fputs ("\n", new_cf);
	    }
	    fputs ("\n", new_cf);
        }
    }
    
    /* free all the change structs
     */
    while (change_list) {
	    section_changes *scp2;
	    scp = change_list->items;
	    while (scp != NULL_ITEM) {
		    scp2 = scp;
		    scp = scp->next;
		    free (scp2->name);
		    free (scp2->value);
		    free (scp2);
	    }
	    cp = change_list;
	    change_list = change_list->next;
	    free (cp->section);
	    if (cp->subsect)
		free (cp->subsect);
	    free (cp);
    }

    /* cleanup, save the old config file, and replace it with the new one.
     * if we have a null backup name, then don't do the backup.
     */
    fclose (new_cf);
    
    if (cf) {
	fclose (cf);
	if(bak_cfname) {
	    unlink (bak_cfname);
	    if (rename (cfname, bak_cfname) != 0) {
#ifdef WINDOWS
#else
	    	if (errno != ENOENT) {
DEBUG (		    printf ("Unable to rename %s to %s", new_cfname, cfname);)
		    config_errno = CE_PERMISSION;
		    return (FALSE);
		}
#endif
		free(bak_cfname);
	    }
        } else {
	    unlink(cfname);  /* if we don't rename it, we have to delete it */
	}
	rename (new_cfname, cfname);
	free(new_cfname);
    }

    return TRUE;
}  /* end of config_flush() */


/*
 * $Log:   K:/22vcs/srclib/config/setconf.c_v  $
 * 
 *    Rev 1.18   18 Nov 1992 16:00:20   seven
 *   Fixed another bug in writing to continuation files.  Ignore leading
 * white space when comparing variables to change.  Check file
 * permission before writing to INI file.
 * 
 *    Rev 1.17   10 Nov 1992 15:20:44   seven
 *   Accept either "-->" or "continuation-file".  Copy remainder of old
 * INI file before switching to continuation file.  Fixed writing to
 * config file.
 * 
 *    Rev 1.16   09 Nov 1992 14:48:52   seven
 * Ben	Carried over Paul's change from conf.h
 *  paul	 added mode argument to sopen call to satisfy TurboC
 * 
 *    Rev 1.15   14 Sep 1992 16:08:04   paul
 *  * 21-Jul-92	rcq	changed to <rwconf.h> to <pctcp/rwconf.h>
 * 
 *    Rev 1.14   28 Jun 1992 22:28:14   arnoff
 * plummer	Changes to config_write and config_flush to handle headings which
 * 		have only a package name and no section nor subsection
 * 
 *    Rev 1.13   14 May 1992 23:20:24   arnoff
 * Ben	Converted setconf() to config_write().  Added flags and package for 
 * 	 writes.  Match both '-' & '_' when comparing variable names.
 * 
 *    Rev 1.12   14 May 1992 16:51:46   arnoff
 * Merged setconf_end() and configure_setconf() and renamed the result
 * config_flush().  Changed setconf_flags to backup_flags and made it a
 * local variable.   ---Ben
 * 
 * 
 *    Rev 1.11   23 Mar 1992 17:17:16   arnoff
 * Changed "foo=bar" to "foo = bar".   ---Ben
 * 
 *    Rev 1.10   12 Mar 1992 15:52:46   arnoff
 * Remove extraneous \r & \n from value in setconf().   ---Ben
 * 
 *    Rev 1.9   09 Mar 1992 22:13:02   arnoff
 * Ben	Added a newline before new sections.  And removed an
 * 	 newline when adding an new entry.
 * 
 *    Rev 1.8   06 Mar 1992 21:18:28   arnoff
 * Ben	Moved a '}' out of an IFDEF.  Moved wls' to test into
 * 	 the do {} while loop.                                
 * 
 *    Rev 1.7   06 Mar 1992 20:23:38   arnoff
 * rehmi	freed up section, subsect, name, and value fields in
 * 	change_list per wls' pointer to bogosity.	    
 * wls	also free bak_cfname and new_cfname		    
 * 	added configure_setconf();			    
 * Ben	Moved a '}' out of an IFDEF.                        
 * 
 *    Rev 1.6   27 Feb 1992 17:17:24   arnoff
 * Ben	Skip over / or \ before adding '`'.
 * 
 *    Rev 1.5   26 Feb 1992 17:49:22   arnoff
 * Fine tune creating temp filename ('OO.INI).
 * 
 *    Rev 1.4   25 Feb 1992 18:47:28   arnoff
 * Don't read the old ini file if it doesn't exist.
 * 
 *    Rev 1.3   21 Feb 1992 14:53:16   arnoff
 * Use correct size for malloc
 * 
 *    Rev 1.2   20 Feb 1992 20:59:16   arnoff
 * Find a safe name for the backup file (e.g. FOO.001).
 * 
 *    Rev 1.1   30 Jan 1992 00:06:24   arnoff
 *  
 */
