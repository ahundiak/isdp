/* 
 * $Header:   J:/22vcs/srclib/rpc4/bindresv.c_v   1.1   18 Nov 1992 00:25:04   rcq  $
 */
#define FTP /*Copyright 1992, FTP Software, Inc.  All Rights Reserved.*/
#ifdef FTP /* added code */
/*
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 * 
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 *
 * (Edit history is maintained in RCS archives.)
 *  17-Nov-92  rcq  removed uneeded include file causing redeclaration
 *                  errors with Borland C Compiler
 */
#else /* FTP superceded code */
static  char sccsid[] = "@(#)bindresvport.c	2.2 88/07/29 4.0 RPCSRC 1.8 88/02/08 SMI";
/*
 * Sun RPC is a product of Sun Microsystems, Inc. and is provided for
 * unrestricted use provided that this legend is included on all tape
 * media and as a part of the software program in whole or part.  Users
 * may copy or modify Sun RPC without charge, but are not authorized
 * to license or distribute it to anyone else except as part of a product or
 * program developed by the user.
 * 
 * SUN RPC IS PROVIDED AS IS WITH NO WARRANTIES OF ANY KIND INCLUDING THE
 * WARRANTIES OF DESIGN, MERCHANTIBILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, OR ARISING FROM A COURSE OF DEALING, USAGE OR TRADE PRACTICE.
 * 
 * Sun RPC is provided with no support and without any obligation on the
 * part of Sun Microsystems, Inc. to assist in its use, correction,
 * modification or enhancement.
 * 
 * SUN MICROSYSTEMS, INC. SHALL HAVE NO LIABILITY WITH RESPECT TO THE
 * INFRINGEMENT OF COPYRIGHTS, TRADE SECRETS OR ANY PATENTS BY SUN RPC
 * OR ANY PART THEREOF.
 * 
 * In no event will Sun Microsystems, Inc. be liable for any lost revenue
 * or profits or other special, indirect and consequential damages, even if
 * Sun has been advised of the possibility of such damages.
 * 
 * Sun Microsystems, Inc.
 * 2550 Garcia Avenue
 * Mountain View, California  94043
 */

/*
 * Copyright (c) 1987 by Sun Microsystems, Inc.
 */
#endif /* FTP */

#ifdef PCTCP /* added code */
#include <sys/types.h>
#include <stdio.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
/* #include <rpc/types.h> */
/* include <pctcp/types.h> */
#else /* FTP superceded code */
#include <bsd.h>  
#include <sys/types.h>
#include <sys/errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#endif /* FTP */
#include <stdlib.h> /* for random */

/*
 * Bind a socket to a privileged IP port
 */
#ifndef MSDOS /* added code */
int
_DLL_FLAGS
bindresvport(
	int sd,
	struct sockaddr_in *sin
)
#else /* FTP superceded code */
int
bindresvport(sd, sin)
	int sd;
	struct sockaddr_in *sin;
#endif /* FTP */
{
	int res;
	static short port;
	struct sockaddr_in myaddr;
#ifdef FTP /* added code */
#else /* FTP superceded code */
	extern int errno;
#endif /* FTP */
	int i;
        
#define STARTPORT 600
#define ENDPORT (IPPORT_RESERVED - 1)
#define NPORTS	(ENDPORT - STARTPORT + 1)

        
	if (sin == (struct sockaddr_in *)0) {
		sin = &myaddr;
		bzero(sin, sizeof (*sin));
		sin->sin_family = AF_INET;
	} else if (sin->sin_family != AF_INET) {
		errno = EPFNOSUPPORT;
		return (-1);
	}
	if (port == 0) {
	        /* removed, for now 
		port = (getpid() % NPORTS) + STARTPORT;
		*/
		srand((unsigned)time(NULL));
		port=rand();
		port=(port % (ENDPORT-STARTPORT))+STARTPORT;
	}
	res = -1;
	errno = EADDRINUSE;
	for (i = 0; i < NPORTS && res < 0 && errno == EADDRINUSE; i++) {
		sin->sin_port = htons(port++);
		if (port > ENDPORT) {
			port = STARTPORT;
		}
		res = bind(sd, (struct sock_addr *)sin,
                            sizeof(struct sockaddr_in));
#ifdef DEBUG		
		printf("bind returned %d on port (net) %d (reg) %d\n",
                        res, sin->sin_port, ntohs(sin->sin_port));
				
	}
	if(res == -1)
            fprintf(stderr, "bindresvport returning -1!\n");
#else
        }
#endif /* debug */        
	return (res);
}
/* 
 * $Log:   J:/22vcs/srclib/rpc4/bindresv.c_v  $
 * 
 *    Rev 1.1   18 Nov 1992 00:25:04   rcq
 * removed unneeded include files causing redeclaration errors w/ Borland
 * 
 *    Rev 1.0   10 Nov 1992 22:57:56   rcq
 * Initial revision.
 */