/* 
 * $Header:   J:/22vcs/srclib/rpc4/getrpcen.c_v   1.0   10 Nov 1992 22:58:52   rcq  $
 */
#define FTP /*Copyright 1992, FTP Software, Inc.  All Rights Reserved.*/
#ifdef FTP /* added code */
/*
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 * 
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 *
 * (Edit history is maintained in RCS archives.)
 * 10-Nov-92  rcq  changed setrpcent() to use config file and FTP_ETC env
 *                 akin to the sockets functions setservent() setprotent().
 *                 changed getrpcent() so it does not try to open rpc file.
 */
#else /* FTP superceded code */
/* @(#)getrpcent.c	2.2 88/07/29 4.0 RPCSRC */
#if !defined(lint) && defined(SCCSIDS)
static  char sccsid[] = "@(#)getrpcent.c 1.9 87/08/11  Copyr 1984 Sun Micro";
#endif

/*
 * Sun RPC is a product of Sun Microsystems, Inc. and is provided for
 * unrestricted use provided that this legend is included on all tape
 * media and as a part of the software program in whole or part.  Users
 * may copy or modify Sun RPC without charge, but are not authorized
 * to license or distribute it to anyone else except as part of a product or
 * program developed by the user.
 * 
 * SUN RPC IS PROVIDED AS IS WITH NO WARRANTIES OF ANY KIND INCLUDING THE
 * WARRANTIES OF DESIGN, MERCHANTIBILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, OR ARISING FROM A COURSE OF DEALING, USAGE OR TRADE PRACTICE.
 * 
 * Sun RPC is provided with no support and without any obligation on the
 * part of Sun Microsystems, Inc. to assist in its use, correction,
 * modification or enhancement.
 * 
 * SUN MICROSYSTEMS, INC. SHALL HAVE NO LIABILITY WITH RESPECT TO THE
 * INFRINGEMENT OF COPYRIGHTS, TRADE SECRETS OR ANY PATENTS BY SUN RPC
 * OR ANY PART THEREOF.
 * 
 * In no event will Sun Microsystems, Inc. be liable for any lost revenue
 * or profits or other special, indirect and consequential damages, even if
 * Sun has been advised of the possibility of such damages.
 * 
 * Sun Microsystems, Inc.
 * 2550 Garcia Avenue
 * Mountain View, California  94043
 */

/*
 * Copyright (c) 1985 by Sun Microsystems, Inc.
 */
#endif /* FTP */

#include <stdio.h>
#include <sys/types.h>
#include <rpc/rpc.h>
#include <netdb.h>
#include <sys/socket.h>

#ifdef FTP /* bq added code */
#include <pctcp/rwconf.h>
#endif

/*
 * Internet version.
 */
struct rpcdata {
	FILE	*rpcf;
	char	*current;
	int	currentlen;
	int	stayopen;
#define	MAXALIASES	35
	char	*rpc_aliases[MAXALIASES];
	struct	rpcent rpc;
	char	line[BUFSIZ+1];
	char	*domain;
} *rpcdata, *_rpcdata();

/* these forward declarations added by dB 7/28 */
/* needed to add these forward function declarations */
#ifdef FTP /* added code */
void
#ifndef MSDOS
_DLL_FLAGS
#endif
setrpcent(
	int f
);
#else /* FTP superceded code */
setrpcent(f);
#endif /* FTP */
#ifdef FTP /* added code */
void
#ifndef MSDOS
_DLL_FLAGS
#endif
endrpcent(void);
#else /* FTP superceded code */
endrpcent();
#endif /* FTP */


#ifdef FTP /* added code */
static struct rpcent *interpret(char *, int);
/*DWH: OS2 comments re gethostent() and inet_ntoa() suggests more work needed.*/
char *strchr();
#else /* FTP superceded code */
static	struct rpcent *interpret();
struct	hostent *gethostent();
char	*inet_ntoa();
static	char *index();
#endif /* FTP */

#ifdef FTP /* bq added code */
#ifndef ETC_LOC
#define ETC_LOC		"FTP_ETC"	/* Env variable pointing to \etc */
#endif
#define	TEST(c, i)	(isalpha(c) || (i && (isdigit(c)  || ((c) == '-') \
			|| ((c) == '_') || ((c) == '.'))))
#define		BUFLEN 64
static char	buf[BUFLEN], *ch_ptr;
#else /* FTP superceded code */
static char RPCDB[] = "/etc/rpc";
#endif /* FTP */

#ifdef FTP /* added code */
/*DWH: OS2 moved setrpcent() & endrpcent up here. Not sure why.  Investigate.*/
static struct rpcdata *
_rpcdata(void)
#else /* FTP superceded code */
static struct rpcdata *
_rpcdata()
#endif /* FTP */
{
	register struct rpcdata *d = rpcdata;

	if (d == 0) {
		d = (struct rpcdata *)calloc(1, sizeof (struct rpcdata));
		rpcdata = d;
	}
	return (d);
}

#ifdef FTP /* added code */
struct rpcent *
#ifndef MSDOS
_DLL_FLAGS
#endif

getrpcbynumber(
	register u_long number
)
#else /* FTP superceded code */
struct rpcent *
getrpcbynumber(number)
	register int number;
#endif /* FTP */
{
	register struct rpcdata *d = _rpcdata();
	register struct rpcent *p;
#ifdef FTP /* added code */
	char *val = NULL;
#else /* FTP superceded code */
	int reason;
	char adrstr[16], *val = NULL;
	int vallen;
#endif /* FTP */

	if (d == 0)
		return (0);
	setrpcent(0);
#ifdef FTP /* added code */
	while ((p = getrpcent()) != (struct rpcent *)NULL) {
		if (p->r_number == number)
			break;
	}
#else /* FTP superceded code */
	while (p = getrpcent()) {
		if (p->r_number == number)
			break;
	}
#endif /* FTP */
	endrpcent();
	return (p);
}

#ifdef FTP /* added code */
struct rpcent *
#ifndef MSDOS
_DLL_FLAGS
#endif
getrpcbyname(
	char *name
)
#else /* FTP superceded code */
struct rpcent *
getrpcbyname(name)
	char *name;
#endif /* FTP */
{
	struct rpcent *rpc;
	char **rp;

	setrpcent(0);
#ifdef FTP /* added code */
	while((rpc = getrpcent()) != (struct rpcent *)NULL) {
		if (strcmp(rpc->r_name, name) == 0)
			return (rpc);
		for (rp = rpc->r_aliases; *rp != NULL; rp++) {
			if (strcmp(*rp, name) == 0)
				return (rpc);
		}
	}
#else /* FTP superceded code */
	while(rpc = getrpcent()) {
		if (strcmp(rpc->r_name, name) == 0)
			return (rpc);
		for (rp = rpc->r_aliases; *rp != NULL; rp++) {
			if (strcmp(*rp, name) == 0)
				return (rpc);
		}
	}
#endif /* FTP */
	endrpcent();
	return (NULL);
}

#ifdef FTP /* added code */
void
#ifndef MSDOS
_DLL_FLAGS
#endif
setrpcent(
	int f
)
#else /* FTP superceded code */
setrpcent(f)
	int f;
#endif /* FTP */
{
	register struct rpcdata *d = _rpcdata();
#ifdef FTP /* bq FTP added code */
	int i;
	int check = 0;

	if(d->rpcf != NULL)
		rewind(d->rpcf);
	else do {  /* We've got to open it: Look for etc directory ptr in
	           config file ...or for FTP_ETC env var ...or look in
		   current directory ...or in default */
	    if ((!check) &&
		((getconf("general","etc-dir",buf,BUFLEN)) 
		  || (ch_ptr = getenv(ETC_LOC)))) {
		if (ch_ptr)
		        strcpy(buf, ch_ptr);
		i = strlen(buf);
		i--;
		if ((buf[i] == '\\') ||
		    (buf[i] == '/'))
			buf[i] = '\0';
			strcat(buf, "\\rpc");
			check = 2;
	    } else if (check < 3) {
		strcpy (buf, "rpc");
		check = 3;  
	    } else {
		strcpy (buf, "c:\\etc\\rpc");
		check = 4;
	    }
	    
	    d->rpcf = fopen(buf, "r");   /* Try Opening File */
#ifdef DEBUG		
	    if (d->rpcf == NULL)
			perror(buf);
#endif		
	} while (!d->rpcf && (check < 4));

#else /* bq FTP superceded code */
	if (d == 0)
		return;
	if (d->rpcf == NULL)
		d->rpcf = fopen(RPCDB, "r");
	else
		rewind(d->rpcf);
#endif	    
	if (d->current)
		free(d->current);
	d->current = NULL;
	d->stayopen |= f;
}

#ifdef FTP /* added code */
void
#ifndef MSDOS
_DLL_FLAGS
#endif
endrpcent(void)
#else /* FTP superceded code */
endrpcent()
#endif /* FTP */
{
	register struct rpcdata *d = _rpcdata();

	if (d == 0)
		return;
	if (d->current && !d->stayopen) {
		free(d->current);
		d->current = NULL;
	}
	if (d->rpcf && !d->stayopen) {
		fclose(d->rpcf);
		d->rpcf = NULL;
	}
}

#ifdef FTP /* added code */
struct rpcent *
#ifndef MSDOS
_DLL_FLAGS
#endif
getrpcent(void)
#else /* FTP superceded code */
struct rpcent *
getrpcent()
#endif /* FTP */
{
#ifdef FTP /* added code */
	char *key = NULL, *val = NULL;
#else /* FTP superceded code */
	struct rpcent *hp;
	int reason;
	char *key = NULL, *val = NULL;
	int keylen, vallen;
#endif /* FTP */
	register struct rpcdata *d = _rpcdata();

#ifdef FTP /* bq added code */
        if (!d)
		return (struct rpcent *)NULL;

	if(!(d->rpcf)) {			/* If RPC ref file not open */
	    setrpcent(0);			/*  try opening it */
	    if(!(d->rpcf))			/* If *still* not open */
		return (struct rpcent *)NULL;	/*  give up, dude! */
	}
	
	if (!(fgets(d->line, BUFSIZ, d->rpcf)))
		return (struct rpcent *)NULL;
#else /* FTP superceded code */
	if (d == 0) 
		return(NULL);

	if (d->rpcf == NULL && (d->rpcf = fopen(RPCDB, "r")) == NULL)
		return (NULL);

	if (fgets(d->line, BUFSIZ, d->rpcf) == NULL)
		return (NULL);
#endif /* FTP */
	return interpret(d->line, strlen(d->line));
}

#ifdef FTP /* added code */
static struct rpcent *
interpret(char *val, int len)
#else /* FTP superceded code */
static struct rpcent *
interpret(val, len)
#endif /* FTP */
{
	register struct rpcdata *d = _rpcdata();
	char *p;
	register char *cp, **q;

	if (d == 0)
#ifdef FTP /* added code */
		return (struct rpcent *)NULL;
#else /* FTP superceded code */
		return;
#endif /* FTP */
	strncpy(d->line, val, len);
	p = d->line;
	d->line[len] = '\n';
	if (*p == '#')
		return (getrpcent());
#ifdef FTP /* added code */
	cp = strchr(p, '#');
#else /* FTP superceded code */
	cp = index(p, '#');
#endif /* FTP */
    {
#ifdef FTP /* added code */
		cp = strchr(p, '\n');
#else /* FTP superceded code */
		cp = index(p, '\n');
#endif /* FTP */
		if (cp == NULL)
			return (getrpcent());
	}
	*cp = '\0';
#ifdef FTP /* added code */
	cp = strchr(p, ' ');
#else /* FTP superceded code */
	cp = index(p, ' ');
#endif /* FTP */
	if (cp == NULL)
    {
#ifdef FTP /* added code */
		cp = strchr(p, '\t');
#else /* FTP superceded code */
		cp = index(p, '\t');
#endif /* FTP */
		if (cp == NULL)
			return (getrpcent());
	}
	*cp++ = '\0';
	/* THIS STUFF IS INTERNET SPECIFIC */
	d->rpc.r_name = d->line;
	while (*cp == ' ' || *cp == '\t')
		cp++;
#ifdef FTP /* added code */
	d->rpc.r_number = atol(cp);
#else /* FTP superceded code */
	d->rpc.r_number = atoi(cp);
#endif /* FTP */
	q = d->rpc.r_aliases = d->rpc_aliases;
#ifdef FTP /* added code */
	cp = strchr(p, ' ');
#else /* FTP superceded code */
	cp = index(p, ' ');
#endif /* FTP */
	if (cp != NULL)
		*cp++ = '\0';
	else
    {
#ifdef FTP /* added code */
		cp = strchr(p, '\t');
#else /* FTP superceded code */
		cp = index(p, '\t');
#endif /* FTP */
		if (cp != NULL)
			*cp++ = '\0';
	}
	while (cp && *cp) {
		if (*cp == ' ' || *cp == '\t') {
			cp++;
			continue;
		}
		if (q < &(d->rpc_aliases[MAXALIASES - 1]))
			*q++ = cp;
#ifdef FTP /* added code */
		cp = strchr(p, ' ');
#else /* FTP superceded code */
		cp = index(p, ' ');
#endif /* FTP */
		if (cp != NULL)
			*cp++ = '\0';
		else
	    {
#ifdef FTP /* added code */
			cp = strchr(p, '\t');
#else /* FTP superceded code */
			cp = index(p, '\t');
#endif /* FTP */
			if (cp != NULL)
				*cp++ = '\0';
		}
	}
	*q = NULL;
	return (&d->rpc);
}
/* 
 * $Log:   J:/22vcs/srclib/rpc4/getrpcen.c_v  $
 * 
 *    Rev 1.0   10 Nov 1992 22:58:52   rcq
 * Initial revision.
 */