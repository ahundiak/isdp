/* 
 * $Header:   J:/22vcs/srclib/rpc4/p_rmt.c_v   1.3   19 Nov 1992 17:45:06   rcq  $
 */
#define FTP /*Copyright 1992, FTP Software, Inc.  All Rights Reserved.*/
#ifdef FTP /* added code */
/*
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 * 
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 *
 * (Edit history is maintained in RCS archives.)
 * Edit History
 * 10-Nov-92  rcq  changed <config.h> to <pctcp/config.h>
 * 17-Nov-92  rcq  removed some unneeded include files causing redeclaration
 *                 errors with Borland C compiler.
 */
#else /* FTP superceded code */
/* @(#)pmap_rmt.c	2.2 88/08/01 4.0 RPCSRC */
/*
 * Sun RPC is a product of Sun Microsystems, Inc. and is provided for
 * unrestricted use provided that this legend is included on all tape
 * media and as a part of the software program in whole or part.  Users
 * may copy or modify Sun RPC without charge, but are not authorized
 * to license or distribute it to anyone else except as part of a product or
 * program developed by the user.
 * 
 * SUN RPC IS PROVIDED AS IS WITH NO WARRANTIES OF ANY KIND INCLUDING THE
 * WARRANTIES OF DESIGN, MERCHANTIBILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, OR ARISING FROM A COURSE OF DEALING, USAGE OR TRADE PRACTICE.
 * 
 * Sun RPC is provided with no support and without any obligation on the
 * part of Sun Microsystems, Inc. to assist in its use, correction,
 * modification or enhancement.
 * 
 * SUN MICROSYSTEMS, INC. SHALL HAVE NO LIABILITY WITH RESPECT TO THE
 * INFRINGEMENT OF COPYRIGHTS, TRADE SECRETS OR ANY PATENTS BY SUN RPC
 * OR ANY PART THEREOF.
 * 
 * In no event will Sun Microsystems, Inc. be liable for any lost revenue
 * or profits or other special, indirect and consequential damages, even if
 * Sun has been advised of the possibility of such damages.
 * 
 * Sun Microsystems, Inc.
 * 2550 Garcia Avenue
 * Mountain View, California  94043
 */
#if !defined(lint) && defined(SCCSIDS)
static char sccsid[] = "@(#)pmap_rmt.c 1.21 87/08/27 Copyr 1984 Sun Micro";
#endif

/*
 * pmap_rmt.c
 * Client interface to pmap rpc service.
 * remote call and broadcast service
 *
 * Copyright (C) 1984, Sun Microsystems, Inc.
 */
#endif /* FTP */

#ifdef FTP /* added code */
#include <types.h>
#include <pctcp/pctcp.h>
#include <pctcp/types.h>  
#include <pctcp/k_config.h>
#include <pctcp/error.h>
#include <pctcp/ipconfig.h>
#include <pctcp/config.h>
#include <rpc/rpc.h>
#include <rpc/pmap_pro.h>
#include <rpc/pmap_cln.h>
#include <rpc/pmap_rmt.h>
#include <sys/socket.h>
#include <stdio.h>
#include <errno.h>
/* #include <net/if.h> */
#include <sys/ioctl.h>
/*#include <arpa/inet.h>*/
#include <4bsddefs.h>
#include <sys/types.h>
#include <sys/time.h> /* for select */
#ifdef MSDOS
#include <stdlib.h> /* for rand */
#include <time.h>
#endif
#else /* FTP superceded code */
#include <rpc/rpc.h>
#include <rpc/pmap_prot.h>
#include <rpc/pmap_clnt.h>
#include <rpc/pmap_rmt.h>
#include <sys/socket.h>
#include <stdio.h>
#include <errno.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#endif /* FTP */
#define MAX_BROADCAST_SIZE 1400

#ifdef FTP /* added code */
static int getbroadcastnets(struct in_addr *addrs, int sock, char *buf);
#else /* FTP superceded code */
extern int errno;
#endif /* FTP */
static struct timeval timeout = { 3, 0 };


/*
 * pmapper remote-call-service interface.
 * This routine is used to call the pmapper remote call service
 * which will look up a service program in the port maps, and then
 * remotely call that routine with the given parameters.  This allows
 * programs to do a lookup and call in one step.
*/
#ifdef FTP /* added code */
enum clnt_stat
#ifndef MSDOS
_DLL_FLAGS
#endif
pmap_rmtcall(
	struct sockaddr_in *addr,
	u_long prog, u_long vers, u_long proc,
	xdrproc_t xdrargs, 
	caddr_t argsp, 
	xdrproc_t xdrres,
	caddr_t resp,
	struct timeval tout,
	u_long *port_ptr
)
#else /* FTP superceded code */
enum clnt_stat
pmap_rmtcall(addr, prog, vers, proc, xdrargs, argsp, xdrres, resp, tout, port_ptr)
	struct sockaddr_in *addr;
	u_long prog, vers, proc;
	xdrproc_t xdrargs, xdrres;
	caddr_t argsp, resp;
	struct timeval tout;
	u_long *port_ptr;
#endif /* FTP */
{
	int socket = -1;
	register CLIENT *client;
	struct rmtcallargs a;
	struct rmtcallres r;
	enum clnt_stat stat;

	addr->sin_port = htons(PMAPPORT);
	client = clntudp_create(addr, PMAPPROG, PMAPVERS, timeout, &socket);
	if (client != (CLIENT *)NULL) {
		a.prog = prog;
		a.vers = vers;
		a.proc = proc;
		a.args_ptr = argsp;
		a.xdr_args = xdrargs;
		r.port_ptr = port_ptr;
		r.results_ptr = resp;
		r.xdr_results = xdrres;
#ifdef FTP /* added code */
		stat = CLNT_CALL(client, (long) PMAPPROC_CALLIT, 
			         (xdrproc_t) xdr_rmtcall_args, (caddr_t) &a,
			         (xdrproc_t) xdr_rmtcallres, (caddr_t) &r, 
				 tout);
#else /* FTP superceded code */
		stat = CLNT_CALL(client, PMAPPROC_CALLIT, xdr_rmtcall_args, &a,
		    xdr_rmtcallres, &r, tout);
#endif /* FTP */
		CLNT_DESTROY(client);
	} else {
		stat = RPC_FAILED;
	}
	(void)close(socket);
	addr->sin_port = 0;
	return (stat);
}


/*
 * XDR remote call arguments
 * written for XDR_ENCODE direction only
 */
#ifdef FTP /* added code */
bool_t
#ifndef MSDOS
_DLL_FLAGS
#endif
xdr_rmtcall_args(
	register XDR *xdrs,
	register struct rmtcallargs *cap
)
#else /* FTP superceded code */
bool_t
xdr_rmtcall_args(xdrs, cap)
	register XDR *xdrs;
	register struct rmtcallargs *cap;
#endif /* FTP */
{
	u_int lenposition, argposition, position;

	if (xdr_u_long(xdrs, &(cap->prog)) &&
	    xdr_u_long(xdrs, &(cap->vers)) &&
	    xdr_u_long(xdrs, &(cap->proc))) {
		lenposition = XDR_GETPOS(xdrs);
		if (! xdr_u_long(xdrs, &(cap->arglen)))
		    return (FALSE);
		argposition = XDR_GETPOS(xdrs);
		if (! (*(cap->xdr_args))(xdrs, cap->args_ptr))
		    return (FALSE);
		position = XDR_GETPOS(xdrs);
		cap->arglen = (u_long)position - (u_long)argposition;
		XDR_SETPOS(xdrs, lenposition);
		if (! xdr_u_long(xdrs, &(cap->arglen)))
		    return (FALSE);
		XDR_SETPOS(xdrs, position);
		return (TRUE);
	}
	return (FALSE);
}

/*
 * XDR remote call results
 * written for XDR_DECODE direction only
 */
#ifdef FTP /* added code */
bool_t
#ifndef MSDOS
_DLL_FLAGS
#endif
xdr_rmtcallres(
	register XDR *xdrs,
	register struct rmtcallres *crp
)
#else /* FTP superceded code */
bool_t
xdr_rmtcallres(xdrs, crp)
	register XDR *xdrs;
	register struct rmtcallres *crp;
#endif /* FTP */
{
	caddr_t port_ptr;

	port_ptr = (caddr_t)crp->port_ptr;
#ifdef FTP /* added code */
	if (xdr_reference(xdrs, &port_ptr, (u_int) sizeof (u_long),
	    (xdrproc_t) xdr_u_long) && xdr_u_long(xdrs, &crp->resultslen)) {
		crp->port_ptr = (u_long *)port_ptr;
		return ((*(crp->xdr_results))(xdrs, crp->results_ptr));
	}
#else /* FTP superceded code */
	if (xdr_reference(xdrs, &port_ptr, sizeof (u_long),
	    xdr_u_long) && xdr_u_long(xdrs, &crp->resultslen)) {
		crp->port_ptr = (u_long *)port_ptr;
		return ((*(crp->xdr_results))(xdrs, crp->results_ptr));
	}
#endif /* FTP */
	return (FALSE);
}


/*
 * The following is kludged-up support for simple rpc broadcasts.
 * Someday a large, complicated system will replace these trivial 
 * routines which only support udp/ip .
 */

/*
 * I have taken the kludge to the 3.9 code, and applied it to the
 * 4.0 code, almost verbatim
 */
 

static int
getbroadcastnets(
	struct in_addr *addrs,
	int sock,  /* any valid socket will do */
	char *buf   /* why allocate more when we can use existing... */
)
/* sock and buf not used for PCTCP */
{
#ifndef PCTCP
	struct ifconf ifc;
        struct ifreq ifreq, *ifr;
	struct sockaddr_in *sin;
        int n, i;

        ifc.ifc_len = UDPMSGSIZE;
        ifc.ifc_buf = buf;
        if (ioctl(sock, SIOCGIFCONF, (char *)&ifc) < 0) {
                perror("broadcast: ioctl (get interface configuration)");
                return (0);
        }
        ifr = ifc.ifc_req;
        for (i = 0, n = ifc.ifc_len/sizeof (struct ifreq); n > 0; n--, ifr++) {
                ifreq = *ifr;
                if (ioctl(sock, SIOCGIFFLAGS, (char *)&ifreq) < 0) {
                        perror("broadcast: ioctl (get interface flags)");
                        continue;
                }
                if ((ifreq.ifr_flags & IFF_BROADCAST) &&
		    (ifreq.ifr_flags & IFF_UP) &&
		    ifr->ifr_addr.sa_family == AF_INET) {
			sin = (struct sockaddr_in *)&ifr->ifr_addr;
#ifdef SIOCGIFBRDADDR   /* 4.3BSD */
			if (ioctl(sock, SIOCGIFBRDADDR, (char *)&ifreq) < 0) {
				addrs[i++] = inet_makeaddr(inet_netof
			    (sin->sin_addr.s_addr), INADDR_ANY);
			} else {
				addrs[i++] = ((struct sockaddr_in*)
				  &ifreq.ifr_addr)->sin_addr;
			}
#else /* 4.2 BSD */
			addrs[i++] = inet_makeaddr(inet_netof
			  (sin->sin_addr.s_addr), INADDR_ANY);
#endif /* def SIOCG... */
		}
	}
	return (i);
#else
#ifdef PRE21
        struct kernel_conf kc;

        if(net_get_k_conf(&kc) < 0) {
                pneterror("getbroadcastnets: net_get_k_conf");
                exit(1);
        }
        addrs[0].s_addr=kc.k_broadcast;
        addrs[1].s_addr=0x0100007f;
        return(2);
#else
        int *size=20, res;
        char buf1[20],buf2[20];
        
        if(get_kernel_info(0, TAG_BCAST_ADDR, 0, (void far *)buf1,
                                (int far *)size) != 0){
            pneterror("getbroadcastnets:get_kernel_info");
                exit(1);
                		}
        addrs[0].s_addr=*(long *)buf1;
        *size=20;
        
        if(get_kernel_info(0, TAG_IP_ADDR, 0, (void far *)buf2,
                                (int far *)size) != 0){
            pneterror("getbroadcastnets:get_kernel_info");
                exit(1);
                		}
        addrs[1].s_addr=*(long *)buf2;
/*        addrs[1].s_addr=0x0100007f;*/
        return(2);
#endif PRE21
#endif /* ndef PCTCP */
}

typedef bool_t (*resultproc_t)();

#ifdef FTP /* added code */
enum clnt_stat 
#ifndef MSDOS
_DLL_FLAGS
#endif
clnt_broadcast(
	u_long		prog,		/* program number */
	u_long		vers,		/* version number */
	u_long		proc,		/* procedure number */
	xdrproc_t	xargs,		/* xdr routine for args */
	caddr_t		argsp,		/* pointer to args */
	xdrproc_t	xresults,	/* xdr routine for results */
	caddr_t		resultsp,	/* pointer to results */
	resultproc_t	eachresult	/* call with each result obtained */
)
#else /* FTP superceded code */
enum clnt_stat 
clnt_broadcast(prog, vers, proc, xargs, argsp, xresults, resultsp, eachresult)
	u_long		prog;		/* program number */
	u_long		vers;		/* version number */
	u_long		proc;		/* procedure number */
	xdrproc_t	xargs;		/* xdr routine for args */
	caddr_t		argsp;		/* pointer to args */
	xdrproc_t	xresults;	/* xdr routine for results */
	caddr_t		resultsp;	/* pointer to results */
	resultproc_t	eachresult;	/* call with each result obtained */
#endif /* FTP */
{
	enum clnt_stat stat;
	AUTH *unix_auth = authunix_create_default();
	XDR xdr_stream;
	register XDR *xdrs = &xdr_stream;
	int outlen, inlen, fromlen, nets;
	register int sock;
	int on = 1;
	int off = 0;
#ifdef FD_SETSIZE
	fd_set mask;
	fd_set readfds;
#else
#ifdef FTP /* added code */
	unsigned long readfds;
	register unsigned long mask;
#else /* FTP superceded code */
	int readfds;
	register int mask;
#endif /* FTP */
#endif /* def FD_SETSIZE */
	register int i;
	bool_t done = FALSE;
	register u_long xid;
	u_long port;
	struct in_addr addrs[20];
	struct sockaddr_in baddr, raddr; /* broadcast and response addresses */
	struct rmtcallargs a;
	struct rmtcallres r;
	struct rpc_msg msg;
	struct timeval t;
#ifdef MSDOS
        int localsock;
        struct sockaddr_in l_baddr;
#endif /* msdos */ 
#ifdef FTP /* added code */
	/* Reduce DLL caller stack size requirements */
	static char outbuf[MAX_BROADCAST_SIZE], inbuf[UDPMSGSIZE];
#else /* FTP superceded code */
	char outbuf[MAX_BROADCAST_SIZE], inbuf[UDPMSGSIZE];
#endif /* FTP */

	/*
	 * initialization: create a socket, a broadcast address, and
	 * preserialize the arguments into a send buffer.
	 */
	if ((sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
		perror("Cannot create socket for broadcast rpc");
		stat = RPC_CANTSEND;
		goto done_broad;
	}
#ifdef MSDOS
        /* need to have two sockets... one for the broadcast, an one
           to the local host, in case the client and server are on
           one machine. */
        if ((localsock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
		perror("Cannot create socket for broadcast rpc");
		stat = RPC_CANTSEND;
		goto done_broad;
	}
#endif /* msdos */	

#ifdef SO_BROADCAST
	if (setsockopt(sock, SOL_SOCKET, SO_BROADCAST, &on, sizeof (on)) < 0) {
		perror("Cannot set socket option SO_BROADCAST");
		stat = RPC_CANTSEND;
		goto done_broad;
	}
#endif /* def SO_BROADCAST */

#ifdef FTP /* added code */
	bzero((char *)&baddr, sizeof (baddr));
	baddr.sin_family = AF_INET;
	baddr.sin_port = 0;
	baddr.sin_addr.s_addr = htonl(INADDR_ANY);
#ifdef MSDOS
#define STARTPORT 600
#define ENDPORT (IPPORT_RESERVED -1)
#define NPORTS (ENDPORT - STARTPORT +1)
        l_baddr=baddr;
        srand((unsigned)time(NULL));
        port=(unsigned long)rand();
        l_baddr.sin_port = htons((port % NPORTS) + STARTPORT);
#ifdef DEBUG        
        printf("Binding 'loopback' socket = %d , port = %d \n",
                        localsock, ntohs(l_baddr.sin_port));
#endif /* debug */                        
        if (bind(localsock, &l_baddr, sizeof (l_baddr)) < 0) {
		perror("clnt_broadcast: bind");
		stat = RPC_CANTSEND;
		goto done_broad;
	}
	/* since, in MSDOS, bind() provided with a port of 0 doesn't
	   assign a port */
	port=(unsigned long)rand();
        baddr.sin_port = htons((port % NPORTS) + STARTPORT);
#endif /*msdos*/
#ifdef DEBUG
        printf("Binding broadcast socket = %d, port = %d \n",
                        sock, ntohs(baddr.sin_port));
#endif /* debug */                        
	if (bind(sock, &baddr, sizeof (baddr)) < 0) {
		perror("clnt_broadcast: bind");
		stat = RPC_CANTSEND;
		goto done_broad;
	}
#endif /* FTP */
#ifdef FD_SETSIZE
	FD_ZERO(&mask);
	FD_SET(sock, &mask);
	FD_SET(localsock, &mask);
#else
	mask = (1 << sock);
	mask |= (1 << localsock);
#endif /* def FD_SETSIZE */
	nets = getbroadcastnets(addrs, sock, inbuf);
	bzero((char *)&baddr, sizeof (baddr));
	baddr.sin_family = AF_INET;
	baddr.sin_port = htons(PMAPPORT);
	baddr.sin_addr.s_addr = htonl(INADDR_ANY);
/*	baddr.sin_addr.S_un.S_addr = htonl(INADDR_ANY); */
	(void)gettimeofday(&t, (struct timezone *)0);
	msg.rm_xid = xid = getpid() ^ t.tv_sec ^ t.tv_usec;
	t.tv_usec = 0;
	msg.rm_direction = CALL;
	msg.rm_call.cb_rpcvers = RPC_MSG_VERSION;
	msg.rm_call.cb_prog = PMAPPROG;
	msg.rm_call.cb_vers = PMAPVERS;
	msg.rm_call.cb_proc = PMAPPROC_CALLIT;
	msg.rm_call.cb_cred = unix_auth->ah_cred;
	msg.rm_call.cb_verf = unix_auth->ah_verf;
	a.prog = prog;
	a.vers = vers;
	a.proc = proc;
	a.xdr_args = xargs;
	a.args_ptr = argsp;
	r.port_ptr = &port;
	r.xdr_results = xresults;
	r.results_ptr = resultsp;
	xdrmem_create(xdrs, outbuf, MAX_BROADCAST_SIZE, XDR_ENCODE);
	if ((! xdr_callmsg(xdrs, &msg)) || (! xdr_rmtcall_args(xdrs, &a))) {
		stat = RPC_CANTENCODEARGS;
		goto done_broad;
	}
	outlen = (int)xdr_getpos(xdrs);
	xdr_destroy(xdrs);
	/*
	 * Basic loop: broadcast a packet and wait a while for response(s).
	 * The response timeout grows larger per iteration.
	 */
	for (t.tv_sec = 4; t.tv_sec <= 14; t.tv_sec += 2) {
		for (i = 0; i < nets; i++) {
			baddr.sin_addr = addrs[i];
#ifdef MSDOS
    /* this section is added because when the socket option SO_BROADCAST
    is set, the sendto() goes to A.B.C.255, whether you like it or not.
    to allow for checking on the same host, this segment is included */
                        switch (i){
                         case 0:	
                          if (sendto(sock, outbuf, outlen, 0,
				(struct sockaddr *)&baddr,
				sizeof (struct sockaddr)) != outlen) {
				perror("Cannot send broadcast packet");
				stat = RPC_CANTSEND;
				goto done_broad;
				}
                        break;      
                         case 1:
                          if (sendto(localsock, outbuf, outlen, 0,
				(struct sockaddr *)&baddr,
				sizeof (struct sockaddr)) != outlen) {
				perror("Cannot send local host packet");
				stat = RPC_CANTSEND;
				goto done_broad;
				}
			break;
                         default:
                            fprintf(stderr, "Too many nets!: p_rmt\n");
                            goto done_broad;
                            break;
			}
#else			

			if (sendto(sock, outbuf, outlen, 0,
				(struct sockaddr *)&baddr,
				sizeof (struct sockaddr)) != outlen) {
				perror("Cannot send broadcast packet");
				stat = RPC_CANTSEND;
				goto done_broad;
			}
#endif /* def msdos */    				
		}
		if (eachresult == NULL) {
			stat = RPC_SUCCESS;
			goto done_broad;
		}
	recv_again:
		msg.acpted_rply.ar_verf = _null_auth;
		msg.acpted_rply.ar_results.where = (caddr_t)&r;
#ifdef FTP /* added code */
		msg.acpted_rply.ar_results.proc = (xdrproc_t)xdr_rmtcallres;
#else /* FTP superceded code */
                msg.acpted_rply.ar_results.proc = xdr_rmtcallres;
#endif /* FTP */
		readfds = mask;
#ifdef FTP /* added code */
		switch (select(_rpc_dtablesize(), (void *)&readfds, 
			       (void *)NULL, (void *)NULL, &t)) {

		case 0:  /* timed out */
			stat = RPC_TIMEDOUT;
			continue;

		case -1:  /* some kind of error */
			if (errno == EINTR)
				goto recv_again;
			perror("Broadcast select problem");
			stat = RPC_CANTRECV;
			goto done_broad;

		}  /* end of select results switch */
#else /* FTP superceded code */
		switch (select(_rpc_dtablesize(), &readfds, (int *)NULL, 
			       (int *)NULL, &t)) {

		case 0:  /* timed out */
			stat = RPC_TIMEDOUT;
			continue;

		case -1:  /* some kind of error */
			if (errno == EINTR)
				goto recv_again;
			perror("Broadcast select problem");
			stat = RPC_CANTRECV;
			goto done_broad;

		}  /* end of select results switch */
#endif /* FTP */
	try_again:
		fromlen = sizeof(struct sockaddr);
#ifdef MSDOS		
		if (FD_ISSET(localsock, &readfds)) {
		    inlen = recvfrom(localsock, inbuf, UDPMSGSIZE, 0,
		        	(struct sockaddr *)&raddr, &fromlen);
		}
		else if (FD_ISSET(sock, &readfds)){
		    inlen = recvfrom(sock, inbuf, UDPMSGSIZE, 0,
			(struct sockaddr *)&raddr, &fromlen);
		}
#else
                inlen = recvfrom(sock, inbuf, UDPMSGSIZE, 0,
			(struct sockaddr *)&raddr, &fromlen);
#endif /* msdos */			
		if (inlen < 0) {
			if (errno == EINTR)
				goto try_again;
			perror("Cannot receive reply to broadcast");
			stat = RPC_CANTRECV;
			goto done_broad;
		}
		if (inlen < sizeof(u_long))
			goto recv_again;
		/*
		 * see if reply transaction id matches sent id.
		 * If so, decode the results.
		 */
		xdrmem_create(xdrs, inbuf, (u_int)inlen, XDR_DECODE);
		if (xdr_replymsg(xdrs, &msg)) {
			if ((msg.rm_xid == xid) &&
				(msg.rm_reply.rp_stat == MSG_ACCEPTED) &&
				(msg.acpted_rply.ar_stat == SUCCESS)) {
				raddr.sin_port = htons((u_short)port);
				done = (*eachresult)(resultsp, &raddr);
			}
			/* otherwise, we just ignore the errors ... */
		} else {
#ifdef notdef
			/* some kind of deserialization problem ... */
			if (msg.rm_xid == xid)
				fprintf(stderr, "Broadcast deserialization problem");
			/* otherwise, just random garbage */
#endif
		}
		xdrs->x_op = XDR_FREE;
#ifdef FTP /* added code */
		msg.acpted_rply.ar_results.proc = (xdrproc_t) xdr_void;
#else /* FTP superceded code */
		msg.acpted_rply.ar_results.proc = xdr_void;
#endif /* FTP */
		(void)xdr_replymsg(xdrs, &msg);
		(void)(*xresults)(xdrs, resultsp);
		xdr_destroy(xdrs);
		if (done) {
			stat = RPC_SUCCESS;
			goto done_broad;
		} else {
			goto recv_again;
		}
	}
done_broad:
	(void)close(sock);
	(void)close(localsock);
	/* attempt to avoid GP fault
	AUTH_DESTROY(unix_auth);
	(*((unix_auth)->ah_ops->ah_destroy))(unix_auth)) */
	authunix_destroy(unix_auth);
	return (stat);
}

/* 
 * $Log:   J:/22vcs/srclib/rpc4/p_rmt.c_v  $
 * 
 *    Rev 1.3   19 Nov 1992 17:45:06   rcq
 * found another random character put in by Epsilon 6.0
 * 
 *    Rev 1.2   18 Nov 1992 12:09:50   rcq
 * fixed random garbage in lines 214 and 221
 * 
 *    Rev 1.1   18 Nov 1992 00:27:14   rcq
 * removed unneeded include files causing redeclaration errors w/ Borland
 * 
 *    Rev 1.0   10 Nov 1992 22:58:16   rcq
 * Initial revision.
 */