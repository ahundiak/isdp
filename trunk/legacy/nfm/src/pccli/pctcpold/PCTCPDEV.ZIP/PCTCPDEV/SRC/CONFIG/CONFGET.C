/*
 * $Header:   H:/22vcs/srclib/config/confget.c_v   1.2   14 Sep 1992 16:07:28   paul  $
 */

/* confget.c	possible replacement for old-style getconf().
 */

/* Copyright (C) 1991 by FTP Software, Inc.  All rights reserved.
 * 
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 * 
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 * 
 * Edit History
 * 23-Jun-91	rehmi	put this in the source tree.
 * 21-Jul-92	rcq	changed to <rwconf.h> to <pctcp/rwconf.h>
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <pctcp/rwconf.h>

int
config_get (char *section, char *subsection, char *name, int instance,
	    char *value, int len)
{
	return config_open (NULL, 0)
	    && config_seek ("pctcp", section, subsection, 0)
	    && config_read (name, instance, value, len, 0)
	    && config_close (0);	/* conditional in-order evaluation */
}

/*
 * $Log:   H:/22vcs/srclib/config/confget.c_v  $
 * 
 *    Rev 1.2   14 Sep 1992 16:07:28   paul
 *  * 21-Jul-92	rcq	changed to <rwconf.h> to <pctcp/rwconf.h>
 * 
 *    Rev 1.1   30 Jan 1992 00:05:46   arnoff
 *  
 */
