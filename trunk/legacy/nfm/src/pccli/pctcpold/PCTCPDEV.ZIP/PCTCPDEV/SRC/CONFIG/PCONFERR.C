/*
 * $Header:   K:/22vcs/srclib/config/pconferr.c_v   1.2   06 Nov 1992 16:49:40   seven  $
 */

/*
 * PCONFERR.C - interpret last config error
 *
 * Copyright (C) 1992 by FTP Software, Inc.
 *
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 *
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 *
 * Edit History
 * 16-Jan-92	paul	created, based loosely on pneterror
 * 23-Jan-92	Ben	Added #9
 * 21-Jul-92	rcq	changed to <rwconf.h> to <pctcp/rwconf.h>
 * 06-Nov-92	Ben	Added three new messages.
 */

#include <stdio.h>
#include <stdlib.h>	/* NULL */
#include <pctcp/rwconf.h>

char *conf_errlist[] = {
	"No error",
	"No PCTCP environment variable found",
	"File specified by PCTCP environment variable not found",
	"Specified pctcp.ini section not found",
	"Specified pctcp.ini entry not found",
	"Specified buffer too small to hold pctcp.ini entry",
	"Illegal NULL section/subsection parameter",
	"File positioning problem, file rewound",
	"Specified continuation file not found",
	"Permission denied on rename of ini file",
	"Attempt to read ini file before opening it",
	"Attempt to call config_read() before config_seek()",
	"Attempt to call config_flush() before closing ini file",
	NULL
	};

void pconferror(char *str)
{
    if ((unsigned)config_errno > MAX_CONFIG_ERR)
	    printf("%s: unknown error (%d)\n", str, config_errno);
    else
	    printf("%s: %s\n", str, conf_errlist[config_errno]);
}

/*
 * $Log:   K:/22vcs/srclib/config/pconferr.c_v  $
 * 
 *    Rev 1.2   06 Nov 1992 16:49:40   seven
 * Added three new error messages.
 * 
 *    Rev 1.1   14 Sep 1992 16:08:02   paul
 *  * 21-Jul-92	rcq	changed to <rwconf.h> to <pctcp/rwconf.h>
 * 
 *    Rev 1.0   30 Jan 1992 00:06:18   arnoff
 *  
 */
