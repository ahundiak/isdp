/* 
 * $Header:   J:/22vcs/srclib/rpc4/c_perror.c_v   1.2   19 Nov 1992 18:49:50   rcq  $
 */
#ifndef FTP
#define FTP /*Copyright 1992, FTP Software, Inc.  All Rights Reserved.*/
#endif /* FTP */
#ifdef FTP /* added code */
#pragma comment (exestr, "$Id: c_perror.c%v 1.2 1992/08/11 15:23:40 db Exp $")
/*
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 * 
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 *
 * RCS automatic edit history:
 * 17-Nov-92  rcq  removed unneeded include files that were causing
 *                 redeclaration errors with Borland C Compiler
 * 
 * $Log:   J:/22vcs/srclib/rpc4/c_perror.c_v  $
 * 
 *    Rev 1.2   19 Nov 1992 18:49:50   rcq
 * fixed random chars
 * 
 *    Rev 1.1   18 Nov 1992 00:25:44   rcq
 * removed unneeded include files causing redeclaration errors w/ Borland
 * 
 *    Rev 1.0   10 Nov 1992 22:59:10   rcq
 * Initial revision.
 * Revision 1.2  1992/08/11  15:23:40  db
 * removed DLL_FLAGS for DOS port
 *
 * Revision 1.1  1992/08/11  14:47:37  db
 * Initial revision
 *
 * Revision 1.2  1992/06/12  03:06:29  dwh
 * Initial FTP port for OS/2.
 *
 * Revision 1.1  1992/03/13  02:17:25  dwh
 * Sun RPCSRC4.0 Porting Base.
 */
#else /* FTP superceded code */
/* @(#)clnt_perror.c	2.1 88/07/29 4.0 RPCSRC */
/*
 * Sun RPC is a product of Sun Microsystems, Inc. and is provided for
 * unrestricted use provided that this legend is included on all tape
 * media and as a part of the software program in whole or part.  Users
 * may copy or modify Sun RPC without charge, but are not authorized
 * to license or distribute it to anyone else except as part of a product or
 * program developed by the user.
 * 
 * SUN RPC IS PROVIDED AS IS WITH NO WARRANTIES OF ANY KIND INCLUDING THE
 * WARRANTIES OF DESIGN, MERCHANTIBILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, OR ARISING FROM A COURSE OF DEALING, USAGE OR TRADE PRACTICE.
 * 
 * Sun RPC is provided with no support and without any obligation on the
 * part of Sun Microsystems, Inc. to assist in its use, correction,
 * modification or enhancement.
 * 
 * SUN MICROSYSTEMS, INC. SHALL HAVE NO LIABILITY WITH RESPECT TO THE
 * INFRINGEMENT OF COPYRIGHTS, TRADE SECRETS OR ANY PATENTS BY SUN RPC
 * OR ANY PART THEREOF.
 * 
 * In no event will Sun Microsystems, Inc. be liable for any lost revenue
 * or profits or other special, indirect and consequential damages, even if
 * Sun has been advised of the possibility of such damages.
 * 
 * Sun Microsystems, Inc.
 * 2550 Garcia Avenue
 * Mountain View, California  94043
 */
#if !defined(lint) && defined(SCCSIDS)
static char sccsid[] = "@(#)clnt_perror.c 1.15 87/10/07 Copyr 1984 Sun Micro";
#endif

/*
 * clnt_perror.c
 *
 * Copyright (C) 1984, Sun Microsystems, Inc.
 *
 */
#endif /* FTP */
#include <stdio.h>

#include <rpc/types.h>
#include <rpc/auth.h>
#include <rpc/clnt.h>

#ifdef FTP /* added code */
/*extern int sprintf(); */
static char *auth_errmsg(enum auth_stat stat);
#else /* FTP superceded code */
extern char *sys_errlist[];
extern char *sprintf();
static char *auth_errmsg();
#endif /* FTP */

extern char *strcpy();

static char *buf;

#ifdef FTP /* added code */
static char *
_buf(void)
#else /* FTP superceded code */
static char *
_buf()
#endif /* FTP */
{

	if (buf == 0)
		buf = (char *)malloc(256);
	return (buf);
}

/*
 * Print reply error info
 */
#ifdef FTP /* added code */
char *
#ifndef MSDOS
_DLL_FLAGS
#endif
clnt_sperror(
	CLIENT *rpch,
	char *s
)
#else /* FTP superceded code */
char *
clnt_sperror(rpch, s)
	CLIENT *rpch;
	char *s;
#endif /* FTP */
{
	struct rpc_err e;
#ifdef FTP /* added code */
#else /* FTP superceded code */
	void clnt_perrno();
#endif /* FTP */
	char *err;
	char *str = _buf();
	char *strstart = str;

	if (str == 0)
		return (0);
	CLNT_GETERR(rpch, &e);

	(void) sprintf(str, "%s: ", s);  
	str += strlen(str);

	(void) strcpy(str, clnt_sperrno(e.re_status));  
	str += strlen(str);

	switch (e.re_status) {
	case RPC_SUCCESS:
	case RPC_CANTENCODEARGS:
	case RPC_CANTDECODERES:
	case RPC_TIMEDOUT:     
	case RPC_PROGUNAVAIL:
	case RPC_PROCUNAVAIL:
	case RPC_CANTDECODEARGS:
	case RPC_SYSTEMERROR:
	case RPC_UNKNOWNHOST:
	case RPC_UNKNOWNPROTO:
	case RPC_PMAPFAILURE:
	case RPC_PROGNOTREGISTERED:
	case RPC_FAILED:
		break;

	case RPC_CANTSEND:
	case RPC_CANTRECV:
#ifdef FTP /* added code */
		(void) sprintf(str, "; errno = %d", e.re_errno);
#else /* FTP superceded code */
		(void) sprintf(str, "; errno = %s",
		    sys_errlist[e.re_errno]); 
#endif /* FTP */
		str += strlen(str);
		break;

	case RPC_VERSMISMATCH:
		(void) sprintf(str,
			"; low version = %lu, high version = %lu", 
			e.re_vers.low, e.re_vers.high);
		str += strlen(str);
		break;

	case RPC_AUTHERROR:
		err = auth_errmsg(e.re_why);
		(void) sprintf(str,"; why = ");
		str += strlen(str);
		if (err != NULL) {
			(void) sprintf(str, "%s",err);
		} else {
			(void) sprintf(str,
				"(unknown authentication error - %d)",
				(int) e.re_why);
		}
		str += strlen(str);
		break;

	case RPC_PROGVERSMISMATCH:
		(void) sprintf(str, 
			"; low version = %lu, high version = %lu", 
			e.re_vers.low, e.re_vers.high);
		str += strlen(str);
		break;

	default:	/* unknown */
		(void) sprintf(str, 
			"; s1 = %lu, s2 = %lu", 
			e.re_lb.s1, e.re_lb.s2);
		str += strlen(str);
		break;
	}
	(void) sprintf(str, "\n");
	return(strstart) ;
}

#ifdef FTP /* added code */
void
#ifndef MSDOS
_DLL_FLAGS
#endif
clnt_perror(
	CLIENT *rpch,
	char *s
)
#else /* FTP superceded code */
void
clnt_perror(rpch, s)
	CLIENT *rpch;
	char *s;
#endif /* FTP */
{
	(void) fprintf(stderr,"%s",clnt_sperror(rpch,s));
}


struct rpc_errtab {
	enum clnt_stat status;
	char *message;
};

static struct rpc_errtab  rpc_errlist[] = {
	{ RPC_SUCCESS, 
		"RPC: Success" }, 
	{ RPC_CANTENCODEARGS, 
		"RPC: Can't encode arguments" },
	{ RPC_CANTDECODERES, 
		"RPC: Can't decode result" },
	{ RPC_CANTSEND, 
		"RPC: Unable to send" },
	{ RPC_CANTRECV, 
		"RPC: Unable to receive" },
	{ RPC_TIMEDOUT, 
		"RPC: Timed out" },
	{ RPC_VERSMISMATCH, 
		"RPC: Incompatible versions of RPC" },
	{ RPC_AUTHERROR, 
		"RPC: Authentication error" },
	{ RPC_PROGUNAVAIL, 
		"RPC: Program unavailable" },
	{ RPC_PROGVERSMISMATCH, 
		"RPC: Program/version mismatch" },
	{ RPC_PROCUNAVAIL, 
		"RPC: Procedure unavailable" },
	{ RPC_CANTDECODEARGS, 
		"RPC: Server can't decode arguments" },
	{ RPC_SYSTEMERROR, 
		"RPC: Remote system error" },
	{ RPC_UNKNOWNHOST, 
		"RPC: Unknown host" },
	{ RPC_UNKNOWNPROTO,
		"RPC: Unknown protocol" },
	{ RPC_PMAPFAILURE, 
		"RPC: Port mapper failure" },
	{ RPC_PROGNOTREGISTERED, 
		"RPC: Program not registered"},
	{ RPC_FAILED, 
		"RPC: Failed (unspecified error)"}
};


/*
 * This interface for use by clntrpc
 */
#ifdef FTP /* added code */
char *
#ifndef MSDOS
_DLL_FLAGS
#endif
clnt_sperrno(
	enum clnt_stat stat
)
#else /* FTP superceded code */
char *
clnt_sperrno(stat)
	enum clnt_stat stat;
#endif /* FTP */
{
	int i;

	for (i = 0; i < sizeof(rpc_errlist)/sizeof(struct rpc_errtab); i++) {
		if (rpc_errlist[i].status == stat) {
			return (rpc_errlist[i].message);
		}
	}
	return ("RPC: (unknown error code)");
}

#ifdef FTP /* added code */
void
#ifndef MSDOS
_DLL_FLAGS
#endif
clnt_perrno(
	enum clnt_stat num
)
#else /* FTP superceded code */
void
clnt_perrno(num)
	enum clnt_stat num;
#endif /* FTP */
{
	(void) fprintf(stderr,"%s",clnt_sperrno(num));
}


#ifdef FTP /* added code */
char *
#ifndef MSDOS
_DLL_FLAGS
#endif
clnt_spcreateerror(
	char *s
)
#else /* FTP superceded code */
char *
clnt_spcreateerror(s)
	char *s;
#endif /* FTP */
{
#ifdef FTP /* added code */
#else /* FTP superceded code */
	extern int sys_nerr;
	extern char *sys_errlist[];
#endif /* FTP */
	char *str = _buf();

	if (str == 0)
		return(0);
	(void) sprintf(str, "%s: ", s);
	(void) strcat(str, clnt_sperrno(rpc_createerr.cf_stat));
	switch (rpc_createerr.cf_stat) {
	case RPC_PMAPFAILURE:
		(void) strcat(str, " - ");
		(void) strcat(str,
		    clnt_sperrno(rpc_createerr.cf_error.re_status));
		break;

	case RPC_SYSTEMERROR:
		(void) strcat(str, " - ");
#ifdef FTP /* added code */
		(void) sprintf(&str[strlen(str)], "Error %d",
		    rpc_createerr.cf_error.re_errno);
#else /* FTP superceded code */
		if (rpc_createerr.cf_error.re_errno > 0
		    && rpc_createerr.cf_error.re_errno < sys_nerr)
			(void) strcat(str,
			    sys_errlist[rpc_createerr.cf_error.re_errno]);
		else
			(void) sprintf(&str[strlen(str)], "Error %d",
			    rpc_createerr.cf_error.re_errno);
#endif /* FTP */
		break;
	}
	(void) strcat(str, "\n");
	return (str);
}

#ifdef FTP /* added code */
void
#ifndef MSDOS
_DLL_FLAGS
#endif
clnt_pcreateerror(char *s)
#else /* FTP superceded code */
void
clnt_pcreateerror(s)
	char *s;
#endif /* FTP */
{
	(void) fprintf(stderr,"%s",clnt_spcreateerror(s));
}

struct auth_errtab {
	enum auth_stat status;	
	char *message;
};

static struct auth_errtab auth_errlist[] = {
	{ AUTH_OK,
		"Authentication OK" },
	{ AUTH_BADCRED,
		"Invalid client credential" },
	{ AUTH_REJECTEDCRED,
		"Server rejected credential" },
	{ AUTH_BADVERF,
		"Invalid client verifier" },
	{ AUTH_REJECTEDVERF,
		"Server rejected verifier" },
	{ AUTH_TOOWEAK,
		"Client credential too weak" },
	{ AUTH_INVALIDRESP,
		"Invalid server verifier" },
	{ AUTH_FAILED,
		"Failed (unspecified error)" },
};

#ifdef FTP /* added code */
static char *
auth_errmsg(enum auth_stat stat)
#else /* FTP superceded code */
static char *
auth_errmsg(stat)
	enum auth_stat stat;
#endif /* FTP */
{
	int i;

	for (i = 0; i < sizeof(auth_errlist)/sizeof(struct auth_errtab); i++) {
		if (auth_errlist[i].status == stat) {
			return(auth_errlist[i].message);
		}
	}
	return(NULL);
}
/* 
 * $Log$
 */