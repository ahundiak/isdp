/*
 * $Header:   H:/22vcs/srclib/config/get_cust.c_v   1.3   14 Sep 1992 16:07:38   paul  $
 */

/* get_cust.c	convert config_seek() and config_read() to use .sys files
 *		(In case you can't tell, this is a kludge (but good, I hope):)
 *
 * get_cust.c requires the presence of the libraries ?netlib.lib and ?pc.lib
 */

/* Copyright (C) 1991,1992 by FTP Software, Inc.  All rights reserved.
 * 
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 * 
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by FTP Software, Inc.
 * 
 * Edit History
 * 30-Dec-91	Ben	It's alive!
 * 02-Jan-92	Ben	Added ini table
 * 06-Jan-92	Ben	Added beginings of a case statement
 * 07-Jan-92	Ben	Added instance
 * 08-Jan-92	Ben	Added begining of ifcust and security stuff.
 *			Added subsection to seek.
 * 10-Jan-92	Ben	Implement ip-security ports
 * 13-Jan-92	Ben	converted local functions and structs to static.
 *			 Only return mininal ifcust information.
 * 14-Jan-92	Ben	Removed alloca (MSC doesn't like it for windows)
 *			 Include winapp.h for windows.  Call get_configstruct
 *			 Also include windows.h.  Replace lswap() and
 *			 inet_ntoa() with my own versions.  Added IP_TOS.
 * 15-Jan-92	Ben	Expanded basic security names.
 * 17-Jan-92	Ben	Mask non IP-TOS bits.  Split into seperate files
 * 21-Jan-92	Ben	Moved Paul's debug macro to get_cust.h
 * 26-Mar-92	Ben	Renamed _config_FILE to _curr_FILE
 * 13-May-92	paul	added function return types
 *			moved struct definitions to get_cust.h
 * 21-Jul-92	rcq	changed to <rwconf.h> to <pctcp/rwconf.h>
 */

/*  Things To Do:
 *	What about wild_card searches?
 *	Do we really want to add setting of variables?
 */

#include <stdio.h>
#include <stdlib.h>
#include <types.h>
#include <string.h>
#include <ctype.h>		/* tolower */

#ifdef WINDOWS
#include <windows.h>
#include <pctcp/winapp.h>	/* This needs to come before pctcp.h */
#endif

#include <pctcp/rwconf.h>
#include <pctcp/options.h>	/* for ip security()	*/
#include <sys/types.h>		/* for u_short & u_char */

#include "get_cust.h"	/* Contains lots of defines */

/*
 *  Macros
 */

/* Returns TRUE if stricmp() worked */
#define STRSAME(a,b)		(stricmp(a,b)==0)


/* addresses section */

static struct vars	addr_list[] = {
    {"addresses",	0,		0,		0},
    {"domain-name-server",	DS,	IPCUST,		ADDR_ARRAY},
    {"cookie-server",	SERVER_COOKIE	,IPCUST,	ADDR},
    {"imagen-print-server", SERVER_IPRINT, IPCUST,	ADDR},
    {"time-server",	TS,		IPCUST,		ADDR_ARRAY},
    {"log-server",	SERVER_LOG,	IPCUST,		ADDR},
    {"mail-relay",	MAILRELAY,	IPCUST,		STRING},
    {"",		0,		0,		0}};


/* lpr section */

static struct vars	lpr_list[] = {
    {"lpr",		0,		0,		0},
    {"server",		SERVER_LPR,	IPCUST,		ADDR},
    {"",		0,		0,		0}};


/* general section */

static struct vars	gen_list[] = {
    {"general",		0,		0,		0},
    {"domain",		DOMAIN,		IPCUST,		STRING},
    {"full-name",	FULLNAME,	IPCUST,		STRING},
    {"host-name",	HOSTNAME,	IPCUST,		STRING},
    {"host-table",	HOSTTABLE,	IPCUST,		STRING},
    {"office",		OFFICE,		IPCUST,		STRING},
    {"phone",		PHONE,		IPCUST,		STRING},
    {"time-zone",	TMLABEL,	IPCUST,		STRING},
    {"time-zone-offset", TMOFFSET,	IPCUST,		NUMBER},
    {"user",		USERID,		IPCUST,		STRING},
    {"",		0,		0,		0}};

    
/* tn section */

static struct vars	tn_list[] = {
    {"tn",		0,		0,		0},
    {"bs",		EMULATOR_ARROW,	IPCUST,		STRING},
    {"del",		EMULATOR_ARROW,	IPCUST,		STRING},
    {"",		0,		0,		0}};


/* vt section */

static struct vars	vt_list[] = {
    {"vt",		0,		0,		0},
    {"wrap",		EMULATOR_WRAP,	IPCUST,		STRING},
    {"",		0,		0,		0}};
    

/* kernel section */

static struct vars	kernel_list[] = {
    {"kernel",		0,		0,		0},
    {"low-window",	WINDOW_LOW,	IPCUST,		NUMBER},
    {"window",		WINDOW,		IPCUST,		NUMBER},
    {"ip-security",	SECURITY_SETTING,  IPCUST,	STRING},
    {"ip-TOS",		IP_TOS,		IPCUST,		NUMBER},
    {"ip-delay",	IP_TOS_DELAY,	IPCUST,		STRING},
    {"ip-reliability",	IP_TOS_RELI,	IPCUST,		STRING},
    {"ip-throughput",	IP_TOS_THRU,	IPCUST,		STRING},
    {"ip-cost",		IP_TOS_COST,	IPCUST,		STRING},
    {"ip-precedence",	IP_PREC,	IPCUST,		STRING},
    {"ip-precedence-matching",	IP_PREC_MATCH,	IPCUST,	STRING},
    {"",		0,		0,		0}};


/* ip security section  */

static struct vars	security_list[] = {
    {"ip-security",	0,		0,		0},
    {"basic-authority",	SECURITY_BASIC_AUTH,    IPCUST,		STRING},
    {"basic-classification", SECURITY_BASIC_CLASS,   IPCUST,	STRING},
    {"matching",	SECURITY_MATCHING,      IPCUST,		STRING},
    {"extended",	SECURITY_EXTENDED,      IPCUST,		STRING},
    {"ports",		SECURITY_PORTS,	        IPCUST,		STRING},
    {"received",	SECURITY_PORTS_RCV,     IPCUST,		STRING},
    {"transmit",	SECURITY_PORTS_XMT,     IPCUST,		STRING},
    {"",		0,		0,		0}};


/* driver section */

static struct vars	driver_list[] = {
    {"ifcust",		0,		0,		0},
//  {"accm",		ACCM,		IFCUST,		STRING},
//? {"apapter",		PORT,		IFCUST,		STRING},
//  {"baud",		BAUD,		IFCUST,		NUMBER},
    {"broadcast-address", BROADCAST,	IFCUST,		ADDR},
//? {"dma",		DMA,		IFCUST,		STRING},  
    {"gw",		GW,		IPCUST,		ADDR},
//? {"io-addr",		BASE,		IFCUST,		NUMBER},
    {"ip-address",	IP_ADDR,	IFCUST,		ADDR},
//? {"irq",		INT_VECT,	IFCUST,		NUMBER},
//  {"link-state",	LINK,		IFCUST,		STRING},
//  {"local-addr",	LADDR,		IFCUST,		ADDR},
//  {"mac-address",	MAC_ADDR,	IFCUST,		STRING}, /* 6 bytes */
//  {"modem-control",	MODEM,		IFCUST,		STRING},
//  {"mru",		MRU,		IFCUST,		NUMBER},
//  {"mtu",		MTU,		IFCUST,		NUMBER},
//  {"open-role",	OPEN_ROLE,	IFCUST,		STRING},
//  {"parity",		PARITY,		IFCUST,		STRING},
//  {"pfc",		PFC,		IFCUST,		STRING},
//  {"port",		SERIAL,		IFCUST,		NUMBER},
//? {"ram-addr",	MEMORY,		IFCUST,		NUMBER},
//? {"ram-size",	RAM_SIZE,	IFCUST,		NUMBER},
//? {"rcv-dma",		RCV_DMA,	IFCUST,		NUMBER},
//  {"remote-addr",	RADDR,		IFCUST,		ADDR},
//  {"rs232-role",	DCE,		IFCUST,		STRING},
//  {"pwsize",		SCOPE0,		IFCUST,		NUMBER},
//  {"fwsize",		SCOPE1,		IFCUST,		NUMBER},
//  {"histsize",	SCOPE2,		IFCUST,		NUMBER},
//  {"t1-timer",	SCOPE3,		IFCUST,		NUMBER},
//  {"n2",		SCOPE4,		IFCUST,		NUMBER},
//  {"flags",		SCOPE5,		IFCUST,		NUMBER},
//  {"x25flags",	SCOPE6,		IFCUST,		NUMBER},
//  {"actage",		SCOPE7,		IFCUST,		NUMBER},
//  {"idleage",		SCOPE8,		IFCUST,		NUMBER},
//  {"histtype",	SCOPE9,		IFCUST,		NUMBER},
//  {"stopbits",	STOPBITS,	IFCUST,		STRING},
    {"subnet-mask",	NETMASK,	IFCUST,		ADDR},
//  {"timeout",		TIMEOUT,	IFCUST,		NUMBER},
//? {"transcevier",	PORT,		IFCUST,		NUMBER},
//  {"x25standard",	X25,		IFCUST,		STRING},
//? {"xmt-dma",		XMT_DMA,	IFCUST,		NUMBER},
    {"",		0,		0,		0}};


#define SECTION_NUM	8
struct vars *section_list[SECTION_NUM];
#define NULL_SECTION	((struct vars *) 0)
struct vars *section_ptr = NULL_SECTION;


#if 0		/* never used */
/* This stuff is for IP Security (borrowed from trans.c) */

/* Basic Security class levels */
static struct	pr_tab	ip_bsec[] = {
	IP_TOPS,	"Top_secret",
	IP_SECR,	"Secret",
	IP_CONFI,	"Confidential",
	IP_UNCLA,	"Unclassified",
	-1, 0
};

/* Basic Security authority levels */
static struct	pr_tab	ip_auth[] = {
	AUTH_GENSER,	"GENSER",
	AUTH_SIOP,	"SIOP",
	AUTH_SCI,	"SCI",
	AUTH_NSA,	"NSA",
	AUTH_DOE,	"DOE",
	-1, 0
};
#endif		/* never used */

/* This stuff is for drv_names (also borrowed from trans.c) */

/* Name of driver.sys files */
static struct	pr_tab	drv_names [] = {
	1, 	"3c500",
	1, 	"3c503",
	1, 	"3c505",
	1, 	"attnau",
	1, 	"bdnint",
	1, 	"dp839eb",
	1, 	"ethdrv",
	1, 	"ifcust",
	1, 	"ibmtr",
	1, 	"intel",
	1, 	"ni5010",
	1, 	"ni5210",
	1, 	"p1300",
	1, 	"p1340",
	1, 	"protint",
	1, 	"ppp",
	1, 	"slip",
	1, 	"scope",
	1, 	"ubnic",
	1, 	"wd8003",
	-1, 0
};


#define MAX_LEN	128
char	section_name[MAX_LEN+1];
char	sub_section_name[MAX_LEN+1];

static int	last_read_failed = FALSE, last_seek_failed = TRUE;
static struct vars	*last_entry = NULL_SECTION;

int	next_instance;


/*
 * Functions begin here...
 */

/*
 *  Return FALSE if couldn't read cust structure.
 *  Return TRUE  if okay.
 *  Return FALL_THROUGH	 if normal library should be used.
 */

int
cust_seek (char *section, char *sub_section, int flags)
{
    int	i;

DEBUG (printf ("cust_seek() called, section = %s\n", section);)

    /* Save current section name, just in case */
    strcpy (section_name, section);
    strcpy (sub_section_name, sub_section);
    next_instance = 0;
    last_read_failed = FALSE;
    last_entry = NULL_SECTION;

    if ((section == NULL) && (strlen (section) == 0))
	return (FALL_THROUGH);

    /* search list for known sections */
    for (i = 0; i < SECTION_NUM; i++)
    {
	if (STRSAME (section, section_list[i]->name)) 
	{
	    /* Save pointer to section */
	    section_ptr = section_list[i];
	    last_seek_failed = FALSE;
	    return (TRUE); 
	}
    }

    if (check_driver (section))
    {
	section_ptr = driver_list;
	last_seek_failed = FALSE;
	return (TRUE); 
    }

    last_seek_failed = TRUE;

    /* Is there any reason, why we'd want to return FALSE? */
    return (FALL_THROUGH);

}  /* end of cust_seek() */

/* yes, I know -> 'flags' : unreferenced formal parameter */

int
cust_read (char *name, int instance, char *value, int len, int flags)
{
    int found = FALSE, ret = FALSE;
    struct vars	*entry_ptr;

    /* We don't deal with wildcard searches */
    if ((name == NULL) || (strlen(name) == 0))
	goto fall_through;

DEBUG (printf ("cust_read() called, name = %s\n", name);)

    if (last_seek_failed)
    {
DEBUG (printf ("error on cust_read %s, section_ptr not set\n", name);)
	return (FALL_THROUGH);
    }

    /* skip the first record (section name) */
    entry_ptr = section_ptr+1;
    
    /* Do we know NAME? */ 
    while (strlen (entry_ptr->name))
    {
	if (STRSAME (name, entry_ptr->name))
	{
	    found = TRUE;
	    break;
	}
	entry_ptr++;	/* try the next name */
    }

    /* If name is not known, call config_seek with SKIP_OLD_INIT */
    if (found == FALSE)
    {
	if (!last_read_failed) 
	{
fall_through:
	    config_seek ("pctcp", section_name, sub_section_name, SKIP_OLD_INIT);
	    last_read_failed = TRUE;
	}

	return (FALL_THROUGH);
    }

    /* Don't return the same entry twice in a row */
    if ((entry_ptr == last_entry) && (entry_ptr->data_type != ADDR_ARRAY)) 
    {
	config_errno = CE_ENTRY;
	return (FALSE);
    }
	
    /* else ... */

    /* Save current entry */
    last_entry = entry_ptr;

    if (entry_ptr->cust == IFCUST)
	ret = get_ifc (entry_ptr, value, len, flags);
    else 
	ret = get_ipc (entry_ptr, instance, value, len, flags);

    return (ret);
}  /* end of cust_read() */

int
check_use_old_init ()
{
    char buf [16];
    /* conditional in-order evaluation */
    if ((_curr_FILE || config_open(NULL, 0))
	&& config_seek ("pctcp", "general", CONF_ANY, SKIP_OLD_INIT)
	&& config_read ("use-old-init-scheme", 0, buf, sizeof(buf), SKIP_OLD_INIT)) 
    {
	/* Accept either "yes" or "true" */
	if ((tolower(*buf) == 'y') || (tolower(*buf) == 't'))
	{
DEBUG (puts ("use-old-init-scheme is TRUE");)
	    /* initialize section_list */

	    section_list[0] = addr_list;
	    section_list[1] = lpr_list;
	    section_list[2] = gen_list;
	    section_list[3] = tn_list;
	    section_list[4] = vt_list;
	    section_list[5] = kernel_list;
	    section_list[6] = security_list;
	    section_list[7] = driver_list;	/* ifcust et al */
	    return (TRUE);
	}
    }

DEBUG (puts ("\nuse-old-init-scheme is FALSE");)
    return (FALSE);
}  /* check_use_old_init () */


int check_driver (char *drv_name)
{
    struct pr_tab *p;

    /* check if driver is one of ours */
    for (p = drv_names; p->val != -1; p++)
	if (stricmp (drv_name, p->name) == 0)
	    return (TRUE);
    return (FALSE);
}  /* end of check_driver () */



/*
 * $Log:   H:/22vcs/srclib/config/get_cust.c_v  $
 * 
 *    Rev 1.3   14 Sep 1992 16:07:38   paul
 *  * 21-Jul-92	rcq	changed to <rwconf.h> to <pctcp/rwconf.h>
 * 
 *    Rev 1.2   13 May 1992 11:53:14   paul
 * added function return types
 * move struct definitions to get_cust.h
 * updated copyright notice
 * 
 *    Rev 1.1   27 Mar 1992 19:51:32   arnoff
 * Renamed _config_FILE to _curr_FILE   ---Ben
 * 
 *    Rev 1.0   30 Jan 1992 00:05:56   arnoff
 *  
 */
